/*! For license information please see component.product-tailsets.js.LICENSE.txt */
// (()=>{var t={1337:(t,e,r)=>{var n=r(7501).default;function o(){"use strict";t.exports=o=function(){return e},t.exports.__esModule=!0,t.exports.default=t.exports;var e={},r=Object.prototype,i=r.hasOwnProperty,a=Object.defineProperty||function(t,e,r){t[e]=r.value},c="function"==typeof Symbol?Symbol:{},u=c.iterator||"@@iterator",s=c.asyncIterator||"@@asyncIterator",l=c.toStringTag||"@@toStringTag";function p(t,e,r){return Object.defineProperty(t,e,{value:r,enumerable:!0,configurable:!0,writable:!0}),t[e]}try{p({},"")}catch(t){p=function(t,e,r){return t[e]=r}}function f(t,e,r,n){var o=e&&e.prototype instanceof v?e:v,i=Object.create(o.prototype),c=new E(n||[]);return a(i,"_invoke",{value:P(t,r,c)}),i}function d(t,e,r){try{return{type:"normal",arg:t.call(e,r)}}catch(t){return{type:"throw",arg:t}}}e.wrap=f;var h={};function v(){}function y(){}function m(){}var g={};p(g,u,(function(){return this}));var w=Object.getPrototypeOf,b=w&&w(w(T([])));b&&b!==r&&i.call(b,u)&&(g=b);var _=m.prototype=v.prototype=Object.create(g);function O(t){["next","throw","return"].forEach((function(e){p(t,e,(function(t){return this._invoke(e,t)}))}))}function x(t,e){function r(o,a,c,u){var s=d(t[o],t,a);if("throw"!==s.type){var l=s.arg,p=l.value;return p&&"object"==n(p)&&i.call(p,"__await")?e.resolve(p.__await).then((function(t){r("next",t,c,u)}),(function(t){r("throw",t,c,u)})):e.resolve(p).then((function(t){l.value=t,c(l)}),(function(t){return r("throw",t,c,u)}))}u(s.arg)}var o;a(this,"_invoke",{value:function(t,n){function i(){return new e((function(e,o){r(t,n,e,o)}))}return o=o?o.then(i,i):i()}})}function P(t,e,r){var n="suspendedStart";return function(o,i){if("executing"===n)throw new Error("Generator is already running");if("completed"===n){if("throw"===o)throw i;return D()}for(r.method=o,r.arg=i;;){var a=r.delegate;if(a){var c=j(a,r);if(c){if(c===h)continue;return c}}if("next"===r.method)r.sent=r._sent=r.arg;else if("throw"===r.method){if("suspendedStart"===n)throw n="completed",r.arg;r.dispatchException(r.arg)}else"return"===r.method&&r.abrupt("return",r.arg);n="executing";var u=d(t,e,r);if("normal"===u.type){if(n=r.done?"completed":"suspendedYield",u.arg===h)continue;return{value:u.arg,done:r.done}}"throw"===u.type&&(n="completed",r.method="throw",r.arg=u.arg)}}}function j(t,e){var r=e.method,n=t.iterator[r];if(void 0===n)return e.delegate=null,"throw"===r&&t.iterator.return&&(e.method="return",e.arg=void 0,j(t,e),"throw"===e.method)||"return"!==r&&(e.method="throw",e.arg=new TypeError("The iterator does not provide a '"+r+"' method")),h;var o=d(n,t.iterator,e.arg);if("throw"===o.type)return e.method="throw",e.arg=o.arg,e.delegate=null,h;var i=o.arg;return i?i.done?(e[t.resultName]=i.value,e.next=t.nextLoc,"return"!==e.method&&(e.method="next",e.arg=void 0),e.delegate=null,h):i:(e.method="throw",e.arg=new TypeError("iterator result is not an object"),e.delegate=null,h)}function L(t){var e={tryLoc:t[0]};1 in t&&(e.catchLoc=t[1]),2 in t&&(e.finallyLoc=t[2],e.afterLoc=t[3]),this.tryEntries.push(e)}function S(t){var e=t.completion||{};e.type="normal",delete e.arg,t.completion=e}function E(t){this.tryEntries=[{tryLoc:"root"}],t.forEach(L,this),this.reset(!0)}function T(t){if(t){var e=t[u];if(e)return e.call(t);if("function"==typeof t.next)return t;if(!isNaN(t.length)){var r=-1,n=function e(){for(;++r<t.length;)if(i.call(t,r))return e.value=t[r],e.done=!1,e;return e.value=void 0,e.done=!0,e};return n.next=n}}return{next:D}}function D(){return{value:void 0,done:!0}}return y.prototype=m,a(_,"constructor",{value:m,configurable:!0}),a(m,"constructor",{value:y,configurable:!0}),y.displayName=p(m,l,"GeneratorFunction"),e.isGeneratorFunction=function(t){var e="function"==typeof t&&t.constructor;return!!e&&(e===y||"GeneratorFunction"===(e.displayName||e.name))},e.mark=function(t){return Object.setPrototypeOf?Object.setPrototypeOf(t,m):(t.__proto__=m,p(t,l,"GeneratorFunction")),t.prototype=Object.create(_),t},e.awrap=function(t){return{__await:t}},O(x.prototype),p(x.prototype,s,(function(){return this})),e.AsyncIterator=x,e.async=function(t,r,n,o,i){void 0===i&&(i=Promise);var a=new x(f(t,r,n,o),i);return e.isGeneratorFunction(r)?a:a.next().then((function(t){return t.done?t.value:a.next()}))},O(_),p(_,l,"Generator"),p(_,u,(function(){return this})),p(_,"toString",(function(){return"[object Generator]"})),e.keys=function(t){var e=Object(t),r=[];for(var n in e)r.push(n);return r.reverse(),function t(){for(;r.length;){var n=r.pop();if(n in e)return t.value=n,t.done=!1,t}return t.done=!0,t}},e.values=T,E.prototype={constructor:E,reset:function(t){if(this.prev=0,this.next=0,this.sent=this._sent=void 0,this.done=!1,this.delegate=null,this.method="next",this.arg=void 0,this.tryEntries.forEach(S),!t)for(var e in this)"t"===e.charAt(0)&&i.call(this,e)&&!isNaN(+e.slice(1))&&(this[e]=void 0)},stop:function(){this.done=!0;var t=this.tryEntries[0].completion;if("throw"===t.type)throw t.arg;return this.rval},dispatchException:function(t){if(this.done)throw t;var e=this;function r(r,n){return a.type="throw",a.arg=t,e.next=r,n&&(e.method="next",e.arg=void 0),!!n}for(var n=this.tryEntries.length-1;n>=0;--n){var o=this.tryEntries[n],a=o.completion;if("root"===o.tryLoc)return r("end");if(o.tryLoc<=this.prev){var c=i.call(o,"catchLoc"),u=i.call(o,"finallyLoc");if(c&&u){if(this.prev<o.catchLoc)return r(o.catchLoc,!0);if(this.prev<o.finallyLoc)return r(o.finallyLoc)}else if(c){if(this.prev<o.catchLoc)return r(o.catchLoc,!0)}else{if(!u)throw new Error("try statement without catch or finally");if(this.prev<o.finallyLoc)return r(o.finallyLoc)}}}},abrupt:function(t,e){for(var r=this.tryEntries.length-1;r>=0;--r){var n=this.tryEntries[r];if(n.tryLoc<=this.prev&&i.call(n,"finallyLoc")&&this.prev<n.finallyLoc){var o=n;break}}o&&("break"===t||"continue"===t)&&o.tryLoc<=e&&e<=o.finallyLoc&&(o=null);var a=o?o.completion:{};return a.type=t,a.arg=e,o?(this.method="next",this.next=o.finallyLoc,h):this.complete(a)},complete:function(t,e){if("throw"===t.type)throw t.arg;return"break"===t.type||"continue"===t.type?this.next=t.arg:"return"===t.type?(this.rval=this.arg=t.arg,this.method="return",this.next="end"):"normal"===t.type&&e&&(this.next=e),h},finish:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var r=this.tryEntries[e];if(r.finallyLoc===t)return this.complete(r.completion,r.afterLoc),S(r),h}},catch:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var r=this.tryEntries[e];if(r.tryLoc===t){var n=r.completion;if("throw"===n.type){var o=n.arg;S(r)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(t,e,r){return this.delegate={iterator:T(t),resultName:e,nextLoc:r},"next"===this.method&&(this.arg=void 0),h}},e}t.exports=o,t.exports.__esModule=!0,t.exports.default=t.exports},7501:t=>{function e(r){return t.exports=e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},t.exports.__esModule=!0,t.exports.default=t.exports,e(r)}t.exports=e,t.exports.__esModule=!0,t.exports.default=t.exports},824:(t,e,r)=>{var n=r(1337)();t.exports=n;try{regeneratorRuntime=n}catch(t){"object"==typeof globalThis?globalThis.regeneratorRuntime=n:Function("r","regeneratorRuntime = r")(n)}}},e={};function r(n){var o=e[n];if(void 0!==o)return o.exports;var i=e[n]={exports:{}};return t[n](i,i.exports,r),i.exports}r.n=t=>{var e=t&&t.__esModule?()=>t.default:()=>t;return r.d(e,{a:e}),e},r.d=(t,e)=>{for(var n in e)r.o(e,n)&&!r.o(t,n)&&Object.defineProperty(t,n,{enumerable:!0,get:e[n]})},r.o=(t,e)=>Object.prototype.hasOwnProperty.call(t,e),(()=>{"use strict";function t(e){return t="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},t(e)}function e(e){var r=function(e,r){if("object"!==t(e)||null===e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var o=n.call(e,r||"default");if("object"!==t(o))return o;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===r?String:Number)(e)}(e,"string");return"symbol"===t(r)?r:String(r)}function n(t,r,n){return(r=e(r))in t?Object.defineProperty(t,r,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[r]=n,t}function o(t,e,r,n,o,i,a){try{var c=t[i](a),u=c.value}catch(t){return void r(t)}c.done?e(u):Promise.resolve(u).then(n,o)}function i(t){return function(){var e=this,r=arguments;return new Promise((function(n,i){var a=t.apply(e,r);function c(t){o(a,n,i,c,u,"next",t)}function u(t){o(a,n,i,c,u,"throw",t)}c(void 0)}))}}var a=r(824),c=r.n(a),u=function(t,e){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},n=new CustomEvent(e,{detail:r});t.dispatchEvent(n)},s=function(){var t=i(c().mark((function t(e,r){var n,o;return c().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return e&&(e.description&&200!==e.status?window.toast.error({message:e.description,icon:!1}):r||window.dispatchEvent(new Event("dynamic-cart-open"))),u(window,"update-react",{}),u(window,"ajax-cart",{cartSections:e.sections}),t.next=5,fetch("/cart.js");case 5:return n=t.sent,t.next=8,n.json();case 8:o=t.sent,window.BOLD&&BOLD.common&&BOLD.common.cartDoctor&&"function"==typeof BOLD.common.cartDoctor.fix&&(o=BOLD.common.cartDoctor.fix(o)),window.BOLD&&BOLD.common&&BOLD.common.eventEmitter&&"function"==typeof BOLD.common.eventEmitter.emit&&BOLD.common.eventEmitter.emit("BOLD_COMMON_cart_loaded",o);case 11:case"end":return t.stop()}}),t)})));return function(e,r){return t.apply(this,arguments)}}(),l=function(){var t=i(c().mark((function t(e){var r,n;return c().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return window.dispatchEvent(new Event("dynamic-cart-loading")),t.next=3,fetch("/cart/add.js",{method:"POST",body:JSON.stringify({items:e,sections:["cart-main","header"]}),headers:{"Content-Type":"application/json"}});case 3:return r=t.sent,t.next=6,r.json();case 6:n=t.sent,s(n);case 8:case"end":return t.stop()}}),t)})));return function(e){return t.apply(this,arguments)}}();function p(t,e){var r=Object.keys(t);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(t);e&&(n=n.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),r.push.apply(r,n)}return r}var f;f={getCart:function(){return $.getJSON("/cart.js")},getProductJSON:function(t){return $.getJSON("/products/".concat(t,".js"))},checkVariantInCart:function(t){return new Promise((function(e,r){f.getCart().then((function(r){var n=r.items.find((function(e){return e.variant_id==t}));e(void 0!==n)}))}))},refreshCart:function(){setTimeout((function(){window.location.reload()}),1e3)},addItemsToCart:function(t){return new Promise((function(e,r){async.eachSeries(t,(function(t,e){f.addItemToCart(t).then((function(){e()}))}),(function(t){t&&console.error(t),e()}))}))},addItemToCart:function(t){var e={quantity:t.quantity,id:t.variant_id};return void 0!==t.properties&&(e.properties=t.properties),console.log(e),new Promise((function(t,r){$.ajax({type:"POST",url:"/cart/add.js",data:e,dataType:"json",success:function(e){t(e)},error:function(t){r(t)}})}))},removeItemsFromCart:function(t){if(0!=t.length){var e={};return t.forEach((function(t){e[t.key]=0})),new Promise((function(t,r){$.post("/cart/update.js",{updates:e,success:function(){t()}})}))}},updateCart:function(t){if(t)return new Promise((function(e,r){$.ajax({type:"POST",url:"/cart/update.js",async:!0,data:{updates:t},dataType:"json",success:function(t){console.log(t),e(t)},error:function(t){console.error(t),r(t)}})}))},updateCartAttribute:function(t){var e={attributes:{}};return e.attributes=t.attributes,new Promise((function(t,r){$.ajax("/cart/update.js",{type:"POST",data:e,success:function(){t()}})}))},observeMutations:function(t,e){if(0!=document.querySelectorAll(t).length){var r=new MutationObserver(e);return r.observe(document.querySelector(t),{attributes:!0,childList:!0,characterData:!0}),r}},debounce:function(t,e,r){var n;return function(){var o=this,i=arguments,a=r&&!n;clearTimeout(n),n=setTimeout((function(){n=null,r||t.apply(o,i)}),e),a&&t.apply(o,i)}},onElementLoad:function(t,e){var r=!1,n=setInterval((function(){document.querySelectorAll(t).length&&(console.log(t+" loaded!"),r=!0),r&&(clearInterval(n),e())}),100)}};function d(){if(Vue.use(Vuex),Vue.filter("resize_image",(function(t,e){var r=t||"";return r=(r=r.replace(".png","_".concat(e,".png"))).replace(".jpg","_".concat(e,".jpg"))})),Vue.filter("handle",(function(t){return t.replace("-"," ")})),Vue.filter("unhandle",(function(t){return t.replace("-"," ")})),Vue.filter("format_money",(function(t){return Shopify.formatMoney(t,theme.moneyFormat)})),document.querySelectorAll("#product-form--tailset").length)new Vue({el:"#product-form--tailset",data:{placeholder_product,options,discount:0,app_url:"https://freedmans-harness.herokuapp.com"},computed:{},mounted:function(){var t=this;t.$set(t,"discount",t.getTotalPrice()-t.placeholder_product.price),t.updatePrice()},updated:function(){this.$nextTick((function(){}))},methods:{getVariantsToAdd:function(){var t=this,e=[];return e=(e=e.concat(t.options.included.variants_to_add)).concat(t.options.backpad.variants_to_add),t.options.hasOwnProperty("crupper")&&(e=e.concat(t.options.crupper.variants_to_add)),t.options.hasOwnProperty("bustle")&&(e=e.concat(t.options.bustle.variants_to_add)),t.options.hasOwnProperty("fleece")&&(e=e.concat(t.options.fleece.variants_to_add)),t.options.nameplate.variants_to_add.filter((function(t){return t.hasOwnProperty("properties")})).forEach((function(t){e=e.concat(t)})),e},getTotalWeight:function(){var t=$('input[name="quantity"]').val();this.variantsToAdd;return this.getVariantsToAdd().reduce((function(e,r){return e+(r.weight||0)*t}),0)},getTotalPrice:function(){return this.getVariantsToAdd().reduce((function(t,e){return t+e.price}),0)},getFinalPrice:function(){this.placeholder_product.price;return this.getTotalPrice()-this.discount},updatePrice:function(){$(".current_price").text(Shopify.formatMoney(this.getFinalPrice(),theme.moneyFormat))},selectOption:function(t,e){var r=$(t.currentTarget).val();e.variants_to_add=[e.options[r].product.variants[0]],e.options[r].hasOwnProperty("included")&&e.variants_to_add.push(e.options[r].included.variants[0]),this.updatePrice()},selectFleece:function(t,e){var r=$(t.currentTarget).val(),n=e.options[0].product.variants[r],o=e.options[0].included.variants[r];e.variants_to_add=[n,o],this.updatePrice()},updateNamePlate:function(t){var e=this,r=[],o=e.options.nameplate.variant;$(".nameplate").each((function(t,e){var i=function(t){for(var e=1;e<arguments.length;e++){var r=null!=arguments[e]?arguments[e]:{};e%2?p(Object(r),!0).forEach((function(e){n(t,e,r[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(r)):p(Object(r)).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(r,e))}))}return t}({},o),a={},c=$(e).val(),u=$(e).data("name");""!==c&&(a[u]=c,i.properties=a,r.push(i))})),e.options.nameplate.variants_to_add=r,e.updatePrice()},newBundleId:function(){return"_"+Math.random().toString(36).substr(2,9)},addToCart:function(t){var e=this,r=e.newBundleId(),n=(e.placeholder_product.variants[0].id,$('input[name="quantity"]').val()),o=(e.getVariantsToAdd().length,e.getVariantsToAdd().map((function(t){var o=e.discount/e.getTotalPrice(),i=Math.ceil(t.price*o);i=Math.round(i+Number.EPSILON)/100;var a=t.properties;return a||(a={}),a._bundle_name=bundleName,a._bundle_group=r,a._title=e.placeholder_product.title,a._image=e.placeholder_product.featured_image,a._url="/products/"+e.placeholder_product.handle,a._price=e.getFinalPrice(),a._total_price=e.getFinalPrice()+e.discount,a._quantity=n,{id:t.id,quantity:n,properties:a}})));l(o)}}})}$(document).ready((function(){d()})),document.addEventListener("shopify:section:load",(function(t){d()}))})()})();


(() => {
    var t = {
            1337: (t, e, r) => {
                var n = r(7501).default;

                function o() {
                    "use strict";
                    t.exports = o = function() {
                        return e
                    }, t.exports.__esModule = !0, t.exports.default = t.exports;
                    var e = {},
                        r = Object.prototype,
                        i = r.hasOwnProperty,
                        a = Object.defineProperty || function(t, e, r) {
                            t[e] = r.value
                        },
                        c = "function" == typeof Symbol ? Symbol : {},
                        u = c.iterator || "@@iterator",
                        s = c.asyncIterator || "@@asyncIterator",
                        l = c.toStringTag || "@@toStringTag";

                    function p(t, e, r) {
                        return Object.defineProperty(t, e, {
                            value: r,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }), t[e]
                    }
                    try {
                        p({}, "")
                    } catch (t) {
                        p = function(t, e, r) {
                            return t[e] = r
                        }
                    }

                    function f(t, e, r, n) {
                        var o = e && e.prototype instanceof v ? e : v,
                            i = Object.create(o.prototype),
                            c = new E(n || []);
                        return a(i, "_invoke", {
                            value: P(t, r, c)
                        }), i
                    }

                    function d(t, e, r) {
                        try {
                            return {
                                type: "normal",
                                arg: t.call(e, r)
                            }
                        } catch (t) {
                            return {
                                type: "throw",
                                arg: t
                            }
                        }
                    }
                    e.wrap = f;
                    var h = {};

                    function v() {}

                    function y() {}

                    function m() {}
                    var g = {};
                    p(g, u, (function() {
                        return this
                    }));
                    var w = Object.getPrototypeOf,
                        b = w && w(w(T([])));
                    b && b !== r && i.call(b, u) && (g = b);
                    var _ = m.prototype = v.prototype = Object.create(g);

                    function O(t) {
                        ["next", "throw", "return"].forEach((function(e) {
                            p(t, e, (function(t) {
                                return this._invoke(e, t)
                            }))
                        }))
                    }

                    function x(t, e) {
                        function r(o, a, c, u) {
                            var s = d(t[o], t, a);
                            if ("throw" !== s.type) {
                                var l = s.arg,
                                    p = l.value;
                                return p && "object" == n(p) && i.call(p, "__await") ? e.resolve(p.__await).then((function(t) {
                                    r("next", t, c, u)
                                }), (function(t) {
                                    r("throw", t, c, u)
                                })) : e.resolve(p).then((function(t) {
                                    l.value = t, c(l)
                                }), (function(t) {
                                    return r("throw", t, c, u)
                                }))
                            }
                            u(s.arg)
                        }
                        var o;
                        a(this, "_invoke", {
                            value: function(t, n) {
                                function i() {
                                    return new e((function(e, o) {
                                        r(t, n, e, o)
                                    }))
                                }
                                return o = o ? o.then(i, i) : i()
                            }
                        })
                    }

                    function P(t, e, r) {
                        var n = "suspendedStart";
                        return function(o, i) {
                            if ("executing" === n) throw new Error("Generator is already running");
                            if ("completed" === n) {
                                if ("throw" === o) throw i;
                                return D()
                            }
                            for (r.method = o, r.arg = i;;) {
                                var a = r.delegate;
                                if (a) {
                                    var c = j(a, r);
                                    if (c) {
                                        if (c === h) continue;
                                        return c
                                    }
                                }
                                if ("next" === r.method) r.sent = r._sent = r.arg;
                                else if ("throw" === r.method) {
                                    if ("suspendedStart" === n) throw n = "completed", r.arg;
                                    r.dispatchException(r.arg)
                                } else "return" === r.method && r.abrupt("return", r.arg);
                                n = "executing";
                                var u = d(t, e, r);
                                if ("normal" === u.type) {
                                    if (n = r.done ? "completed" : "suspendedYield", u.arg === h) continue;
                                    return {
                                        value: u.arg,
                                        done: r.done
                                    }
                                }
                                "throw" === u.type && (n = "completed", r.method = "throw", r.arg = u.arg)
                            }
                        }
                    }

                    function j(t, e) {
                        var r = e.method,
                            n = t.iterator[r];
                        if (void 0 === n) return e.delegate = null, "throw" === r && t.iterator.return && (e.method = "return", e.arg = void 0, j(t, e), "throw" === e.method) || "return" !== r && (e.method = "throw", e.arg = new TypeError("The iterator does not provide a '" + r + "' method")), h;
                        var o = d(n, t.iterator, e.arg);
                        if ("throw" === o.type) return e.method = "throw", e.arg = o.arg, e.delegate = null, h;
                        var i = o.arg;
                        return i ? i.done ? (e[t.resultName] = i.value, e.next = t.nextLoc, "return" !== e.method && (e.method = "next", e.arg = void 0), e.delegate = null, h) : i : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, h)
                    }

                    function L(t) {
                        var e = {
                            tryLoc: t[0]
                        };
                        1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
                    }

                    function S(t) {
                        var e = t.completion || {};
                        e.type = "normal", delete e.arg, t.completion = e
                    }

                    function E(t) {
                        this.tryEntries = [{
                            tryLoc: "root"
                        }], t.forEach(L, this), this.reset(!0)
                    }

                    function T(t) {
                        if (t) {
                            var e = t[u];
                            if (e) return e.call(t);
                            if ("function" == typeof t.next) return t;
                            if (!isNaN(t.length)) {
                                var r = -1,
                                    n = function e() {
                                        for (; ++r < t.length;)
                                            if (i.call(t, r)) return e.value = t[r], e.done = !1, e;
                                        return e.value = void 0, e.done = !0, e
                                    };
                                return n.next = n
                            }
                        }
                        return {
                            next: D
                        }
                    }

                    function D() {
                        return {
                            value: void 0,
                            done: !0
                        }
                    }
                    return y.prototype = m, a(_, "constructor", {
                        value: m,
                        configurable: !0
                    }), a(m, "constructor", {
                        value: y,
                        configurable: !0
                    }), y.displayName = p(m, l, "GeneratorFunction"), e.isGeneratorFunction = function(t) {
                        var e = "function" == typeof t && t.constructor;
                        return !!e && (e === y || "GeneratorFunction" === (e.displayName || e.name))
                    }, e.mark = function(t) {
                        return Object.setPrototypeOf ? Object.setPrototypeOf(t, m) : (t.__proto__ = m, p(t, l, "GeneratorFunction")), t.prototype = Object.create(_), t
                    }, e.awrap = function(t) {
                        return {
                            __await: t
                        }
                    }, O(x.prototype), p(x.prototype, s, (function() {
                        return this
                    })), e.AsyncIterator = x, e.async = function(t, r, n, o, i) {
                        void 0 === i && (i = Promise);
                        var a = new x(f(t, r, n, o), i);
                        return e.isGeneratorFunction(r) ? a : a.next().then((function(t) {
                            return t.done ? t.value : a.next()
                        }))
                    }, O(_), p(_, l, "Generator"), p(_, u, (function() {
                        return this
                    })), p(_, "toString", (function() {
                        return "[object Generator]"
                    })), e.keys = function(t) {
                        var e = Object(t),
                            r = [];
                        for (var n in e) r.push(n);
                        return r.reverse(),
                            function t() {
                                for (; r.length;) {
                                    var n = r.pop();
                                    if (n in e) return t.value = n, t.done = !1, t
                                }
                                return t.done = !0, t
                            }
                    }, e.values = T, E.prototype = {
                        constructor: E,
                        reset: function(t) {
                            if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(S), !t)
                                for (var e in this) "t" === e.charAt(0) && i.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0)
                        },
                        stop: function() {
                            this.done = !0;
                            var t = this.tryEntries[0].completion;
                            if ("throw" === t.type) throw t.arg;
                            return this.rval
                        },
                        dispatchException: function(t) {
                            if (this.done) throw t;
                            var e = this;

                            function r(r, n) {
                                return a.type = "throw", a.arg = t, e.next = r, n && (e.method = "next", e.arg = void 0), !!n
                            }
                            for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                                var o = this.tryEntries[n],
                                    a = o.completion;
                                if ("root" === o.tryLoc) return r("end");
                                if (o.tryLoc <= this.prev) {
                                    var c = i.call(o, "catchLoc"),
                                        u = i.call(o, "finallyLoc");
                                    if (c && u) {
                                        if (this.prev < o.catchLoc) return r(o.catchLoc, !0);
                                        if (this.prev < o.finallyLoc) return r(o.finallyLoc)
                                    } else if (c) {
                                        if (this.prev < o.catchLoc) return r(o.catchLoc, !0)
                                    } else {
                                        if (!u) throw new Error("try statement without catch or finally");
                                        if (this.prev < o.finallyLoc) return r(o.finallyLoc)
                                    }
                                }
                            }
                        },
                        abrupt: function(t, e) {
                            for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                                var n = this.tryEntries[r];
                                if (n.tryLoc <= this.prev && i.call(n, "finallyLoc") && this.prev < n.finallyLoc) {
                                    var o = n;
                                    break
                                }
                            }
                            o && ("break" === t || "continue" === t) && o.tryLoc <= e && e <= o.finallyLoc && (o = null);
                            var a = o ? o.completion : {};
                            return a.type = t, a.arg = e, o ? (this.method = "next", this.next = o.finallyLoc, h) : this.complete(a)
                        },
                        complete: function(t, e) {
                            if ("throw" === t.type) throw t.arg;
                            return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), h
                        },
                        finish: function(t) {
                            for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                var r = this.tryEntries[e];
                                if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), S(r), h
                            }
                        },
                        catch: function(t) {
                            for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                var r = this.tryEntries[e];
                                if (r.tryLoc === t) {
                                    var n = r.completion;
                                    if ("throw" === n.type) {
                                        var o = n.arg;
                                        S(r)
                                    }
                                    return o
                                }
                            }
                            throw new Error("illegal catch attempt")
                        },
                        delegateYield: function(t, e, r) {
                            return this.delegate = {
                                iterator: T(t),
                                resultName: e,
                                nextLoc: r
                            }, "next" === this.method && (this.arg = void 0), h
                        }
                    }, e
                }
                t.exports = o, t.exports.__esModule = !0, t.exports.default = t.exports
            },
            7501: t => {
                function e(r) {
                    return t.exports = e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    }, t.exports.__esModule = !0, t.exports.default = t.exports, e(r)
                }
                t.exports = e, t.exports.__esModule = !0, t.exports.default = t.exports
            },
            824: (t, e, r) => {
                var n = r(1337)();
                t.exports = n;
                try {
                    regeneratorRuntime = n
                } catch (t) {
                    "object" == typeof globalThis ? globalThis.regeneratorRuntime = n : Function("r", "regeneratorRuntime = r")(n)
                }
            }
        },
        e = {};

    function r(n) {
        var o = e[n];
        if (void 0 !== o) return o.exports;
        var i = e[n] = {
            exports: {}
        };
        return t[n](i, i.exports, r), i.exports
    }
    r.n = t => {
        var e = t && t.__esModule ? () => t.default : () => t;
        return r.d(e, {
            a: e
        }), e
    }, r.d = (t, e) => {
        for (var n in e) r.o(e, n) && !r.o(t, n) && Object.defineProperty(t, n, {
            enumerable: !0,
            get: e[n]
        })
    }, r.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e), (() => {
        "use strict";

        function t(e) {
            return t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            }, t(e)
        }

        function e(e) {
            var r = function(e, r) {
                if ("object" !== t(e) || null === e) return e;
                var n = e[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var o = n.call(e, r || "default");
                    if ("object" !== t(o)) return o;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === r ? String : Number)(e)
            }(e, "string");
            return "symbol" === t(r) ? r : String(r)
        }

        function n(t, r, n) {
            return (r = e(r)) in t ? Object.defineProperty(t, r, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[r] = n, t
        }

        function o(t, e, r, n, o, i, a) {
            try {
                var c = t[i](a),
                    u = c.value
            } catch (t) {
                return void r(t)
            }
            c.done ? e(u) : Promise.resolve(u).then(n, o)
        }

        function i(t) {
            return function() {
                var e = this,
                    r = arguments;
                return new Promise((function(n, i) {
                    var a = t.apply(e, r);

                    function c(t) {
                        o(a, n, i, c, u, "next", t)
                    }

                    function u(t) {
                        o(a, n, i, c, u, "throw", t)
                    }
                    c(void 0)
                }))
            }
        }
        var a = r(824),
            c = r.n(a),
            u = function(t, e) {
                var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                    n = new CustomEvent(e, {
                        detail: r
                    });
                t.dispatchEvent(n)
            },
            s = function() {
                var t = i(c().mark((function t(e, r) {
                    var n, o;
                    return c().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e && (e.description && 200 !== e.status ? window.toast.error({
                                    message: e.description,
                                    icon: !1
                                }) : r || window.dispatchEvent(new Event("dynamic-cart-open"))), u(window, "update-react", {}), u(window, "ajax-cart", {
                                    cartSections: e.sections
                                }), t.next = 5, fetch("/cart.js");
                            case 5:
                                return n = t.sent, t.next = 8, n.json();
                            case 8:
                                o = t.sent, window.BOLD && BOLD.common && BOLD.common.cartDoctor && "function" == typeof BOLD.common.cartDoctor.fix && (o = BOLD.common.cartDoctor.fix(o)), window.BOLD && BOLD.common && BOLD.common.eventEmitter && "function" == typeof BOLD.common.eventEmitter.emit && BOLD.common.eventEmitter.emit("BOLD_COMMON_cart_loaded", o);
                            case 11:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                })));
                return function(e, r) {
                    return t.apply(this, arguments)
                }
            }(),
            l = function() {
                var t = i(c().mark((function t(e) {
                    var r, n;
                    return c().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return window.dispatchEvent(new Event("dynamic-cart-loading")), t.next = 3, fetch("/cart/add.js", {
                                    method: "POST",
                                    body: JSON.stringify({
                                        items: e,
                                        sections: ["cart-main", "header"]
                                    }),
                                    headers: {
                                        "Content-Type": "application/json"
                                    }
                                });
                            case 3:
                                return r = t.sent, t.next = 6, r.json();
                            case 6:
                                n = t.sent, s(n);
                            case 8:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                })));
                return function(e) {
                    return t.apply(this, arguments)
                }
            }();

        function p(t, e) {
            var r = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(t);
                e && (n = n.filter((function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                }))), r.push.apply(r, n)
            }
            return r
        }
        var f;
        f = {
            getCart: function() {
                return $.getJSON("/cart.js")
            },
            getProductJSON: function(t) {
                return $.getJSON("/products/".concat(t, ".js"))
            },
            checkVariantInCart: function(t) {
                return new Promise((function(e, r) {
                    f.getCart().then((function(r) {
                        var n = r.items.find((function(e) {
                            return e.variant_id == t
                        }));
                        e(void 0 !== n)
                    }))
                }))
            },
            refreshCart: function() {
                setTimeout((function() {
                    window.location.reload()
                }), 1e3)
            },
            addItemsToCart: function(t) {
                return new Promise((function(e, r) {
                    async.eachSeries(t, (function(t, e) {
                        f.addItemToCart(t).then((function() {
                            e()
                        }))
                    }), (function(t) {
                        t && console.error(t), e()
                    }))
                }))
            },
            addItemToCart: function(t) {
                var e = {
                    quantity: t.quantity,
                    id: t.variant_id
                };
                return void 0 !== t.properties && (e.properties = t.properties), console.log(e), new Promise((function(t, r) {
                    $.ajax({
                        type: "POST",
                        url: "/cart/add.js",
                        data: e,
                        dataType: "json",
                        success: function(e) {
                            t(e)
                        },
                        error: function(t) {
                            r(t)
                        }
                    })
                }))
            },
            removeItemsFromCart: function(t) {
                if (0 != t.length) {
                    var e = {};
                    return t.forEach((function(t) {
                        e[t.key] = 0
                    })), new Promise((function(t, r) {
                        $.post("/cart/update.js", {
                            updates: e,
                            success: function() {
                                t()
                            }
                        })
                    }))
                }
            },
            updateCart: function(t) {
                if (t) return new Promise((function(e, r) {
                    $.ajax({
                        type: "POST",
                        url: "/cart/update.js",
                        async: !0,
                        data: {
                            updates: t
                        },
                        dataType: "json",
                        success: function(t) {
                            console.log(t), e(t)
                        },
                        error: function(t) {
                            console.error(t), r(t)
                        }
                    })
                }))
            },
            updateCartAttribute: function(t) {
                var e = {
                    attributes: {}
                };
                return e.attributes = t.attributes, new Promise((function(t, r) {
                    $.ajax("/cart/update.js", {
                        type: "POST",
                        data: e,
                        success: function() {
                            t()
                        }
                    })
                }))
            },
            observeMutations: function(t, e) {
                if (0 != document.querySelectorAll(t).length) {
                    var r = new MutationObserver(e);
                    return r.observe(document.querySelector(t), {
                        attributes: !0,
                        childList: !0,
                        characterData: !0
                    }), r
                }
            },
            debounce: function(t, e, r) {
                var n;
                return function() {
                    var o = this,
                        i = arguments,
                        a = r && !n;
                    clearTimeout(n), n = setTimeout((function() {
                        n = null, r || t.apply(o, i)
                    }), e), a && t.apply(o, i)
                }
            },
            onElementLoad: function(t, e) {
                var r = !1,
                    n = setInterval((function() {
                        document.querySelectorAll(t).length && (console.log(t + " loaded!"), r = !0), r && (clearInterval(n), e())
                    }), 100)
            }
        };

        function d() {
            if (Vue.use(Vuex), Vue.filter("resize_image", (function(t, e) {
                    var r = t || "";
                    return r = (r = r.replace(".png", "_".concat(e, ".png"))).replace(".jpg", "_".concat(e, ".jpg"))
                })), Vue.filter("handle", (function(t) {
                    return t.replace("-", " ")
                })), Vue.filter("unhandle", (function(t) {
                    return t.replace("-", " ")
                })), Vue.filter("format_money", (function(t) {
                    return Shopify.formatMoney(t, theme.moneyFormat)
                })), document.querySelectorAll("#product-form--jogharness").length) new Vue({
                el: "#product-form--jogharness",
                data: {
                    placeholder_product,
                    options,
                    discount: 0,
                    app_url: "https://freedmans-harness.herokuapp.com"
                },
                computed: {},
                mounted: function() {
                    var t = this;
                    t.$set(t, "discount", t.getTotalPrice() - t.placeholder_product.price), t.updatePrice()
                },
                updated: function() {
                    this.$nextTick((function() {}))
                },
                methods: {
                    getVariantsToAdd: function() {
                        var t = this,
                            e = [];
                        return e = (e = e.concat(t.options.included.variants_to_add)).concat(t.options.backpad.variants_to_add), t.options.hasOwnProperty("crupper") && (e = e.concat(t.options.crupper.variants_to_add)), t.options.hasOwnProperty("bustle") && (e = e.concat(t.options.bustle.variants_to_add)), t.options.hasOwnProperty("fleece") && (e = e.concat(t.options.fleece.variants_to_add)), t.options.nameplate.variants_to_add.filter((function(t) {
                            return t.hasOwnProperty("properties")
                        })).forEach((function(t) {
                            e = e.concat(t)
                        })), e
                    },
                    getTotalWeight: function() {
                        var t = $('input[name="quantity"]').val();
                        this.variantsToAdd;
                        return this.getVariantsToAdd().reduce((function(e, r) {
                            return e + (r.weight || 0) * t
                        }), 0)
                    },
                    getTotalPrice: function() {
                        return this.getVariantsToAdd().reduce((function(t, e) {
                            return t + e.price
                        }), 0)
                    },
                    getFinalPrice: function() {
                        this.placeholder_product.price;
                        return this.getTotalPrice() - this.discount
                    },
                    updatePrice: function() {
                        $(".current_price").text(Shopify.formatMoney(this.getFinalPrice(), theme.moneyFormat))
                    },
                    selectOption: function(t, e) {
                        var r = $(t.currentTarget).val();
                        e.variants_to_add = [e.options[r].product.variants[0]], e.options[r].hasOwnProperty("included") && e.variants_to_add.push(e.options[r].included.variants[0]), this.updatePrice()
                    },
                    selectFleece: function(t, e) {
                        var r = $(t.currentTarget).val(),
                            n = e.options[0].product.variants[r],
                            o = e.options[0].included.variants[r];
                        e.variants_to_add = [n, o], this.updatePrice()
                    },
                    updateNamePlate: function(t) {
                        var e = this,
                            r = [],
                            o = e.options.nameplate.variant;
                        $(".nameplate").each((function(t, e) {
                            var i = function(t) {
                                    for (var e = 1; e < arguments.length; e++) {
                                        var r = null != arguments[e] ? arguments[e] : {};
                                        e % 2 ? p(Object(r), !0).forEach((function(e) {
                                            n(t, e, r[e])
                                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : p(Object(r)).forEach((function(e) {
                                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e))
                                        }))
                                    }
                                    return t
                                }({}, o),
                                a = {},
                                c = $(e).val(),
                                u = $(e).data("name");
                            "" !== c && (a[u] = c, i.properties = a, r.push(i))
                        })), e.options.nameplate.variants_to_add = r, e.updatePrice()
                    },
                    newBundleId: function() {
                        return "_" + Math.random().toString(36).substr(2, 9)
                    },
                    addToCart: function(t) {
                      console.log("this is disc");
                        var e = this,
                            r = e.newBundleId(),
                            n = (e.placeholder_product.variants[0].id, $('input[name="quantity"]').val()),
                            o = (e.getVariantsToAdd().length, e.getVariantsToAdd().map((function(t) {
                                var o = e.discount / e.getTotalPrice(),
                                    i = Math.ceil(t.price * o);
                                i = Math.round(i + Number.EPSILON) / 100;
                                var a = t.properties;
                                return a || (a = {}), a._bundle_name = bundleName, a._bundle_group = r, a._title = e.placeholder_product.title, a._image = e.placeholder_product.featured_image, a._url = "/products/" + e.placeholder_product.handle, a._price = e.getFinalPrice(), a._total_price = e.getFinalPrice() + e.discount, a._quantity = n, {
                                    id: t.id,
                                    quantity: n,
                                    properties: a
                                }
                            })));
                        l(o)
                    }
                }
            })
        }
        $(document).ready((function() {
            d()
        })), document.addEventListener("shopify:section:load", (function(t) {
            d()
        }))
    })()
})();