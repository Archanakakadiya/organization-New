/*! For license information please see component.product-form.js.LICENSE.txt */
// (()=>{var t={1337:(t,e,r)=>{var n=r(7501).default;function o(){"use strict";t.exports=o=function(){return e},t.exports.__esModule=!0,t.exports.default=t.exports;var e={},r=Object.prototype,i=r.hasOwnProperty,a=Object.defineProperty||function(t,e,r){t[e]=r.value},c="function"==typeof Symbol?Symbol:{},u=c.iterator||"@@iterator",s=c.asyncIterator||"@@asyncIterator",p=c.toStringTag||"@@toStringTag";function l(t,e,r){return Object.defineProperty(t,e,{value:r,enumerable:!0,configurable:!0,writable:!0}),t[e]}try{l({},"")}catch(t){l=function(t,e,r){return t[e]=r}}function f(t,e,r,n){var o=e&&e.prototype instanceof m?e:m,i=Object.create(o.prototype),c=new T(n||[]);return a(i,"_invoke",{value:S(t,r,c)}),i}function d(t,e,r){try{return{type:"normal",arg:t.call(e,r)}}catch(t){return{type:"throw",arg:t}}}e.wrap=f;var h={};function m(){}function y(){}function v(){}var b={};l(b,u,(function(){return this}));var w=Object.getPrototypeOf,g=w&&w(w(P([])));g&&g!==r&&i.call(g,u)&&(b=g);var E=v.prototype=m.prototype=Object.create(b);function _(t){["next","throw","return"].forEach((function(e){l(t,e,(function(t){return this._invoke(e,t)}))}))}function x(t,e){function r(o,a,c,u){var s=d(t[o],t,a);if("throw"!==s.type){var p=s.arg,l=p.value;return l&&"object"==n(l)&&i.call(l,"__await")?e.resolve(l.__await).then((function(t){r("next",t,c,u)}),(function(t){r("throw",t,c,u)})):e.resolve(l).then((function(t){p.value=t,c(p)}),(function(t){return r("throw",t,c,u)}))}u(s.arg)}var o;a(this,"_invoke",{value:function(t,n){function i(){return new e((function(e,o){r(t,n,e,o)}))}return o=o?o.then(i,i):i()}})}function S(t,e,r){var n="suspendedStart";return function(o,i){if("executing"===n)throw new Error("Generator is already running");if("completed"===n){if("throw"===o)throw i;return A()}for(r.method=o,r.arg=i;;){var a=r.delegate;if(a){var c=L(a,r);if(c){if(c===h)continue;return c}}if("next"===r.method)r.sent=r._sent=r.arg;else if("throw"===r.method){if("suspendedStart"===n)throw n="completed",r.arg;r.dispatchException(r.arg)}else"return"===r.method&&r.abrupt("return",r.arg);n="executing";var u=d(t,e,r);if("normal"===u.type){if(n=r.done?"completed":"suspendedYield",u.arg===h)continue;return{value:u.arg,done:r.done}}"throw"===u.type&&(n="completed",r.method="throw",r.arg=u.arg)}}}function L(t,e){var r=e.method,n=t.iterator[r];if(void 0===n)return e.delegate=null,"throw"===r&&t.iterator.return&&(e.method="return",e.arg=void 0,L(t,e),"throw"===e.method)||"return"!==r&&(e.method="throw",e.arg=new TypeError("The iterator does not provide a '"+r+"' method")),h;var o=d(n,t.iterator,e.arg);if("throw"===o.type)return e.method="throw",e.arg=o.arg,e.delegate=null,h;var i=o.arg;return i?i.done?(e[t.resultName]=i.value,e.next=t.nextLoc,"return"!==e.method&&(e.method="next",e.arg=void 0),e.delegate=null,h):i:(e.method="throw",e.arg=new TypeError("iterator result is not an object"),e.delegate=null,h)}function O(t){var e={tryLoc:t[0]};1 in t&&(e.catchLoc=t[1]),2 in t&&(e.finallyLoc=t[2],e.afterLoc=t[3]),this.tryEntries.push(e)}function j(t){var e=t.completion||{};e.type="normal",delete e.arg,t.completion=e}function T(t){this.tryEntries=[{tryLoc:"root"}],t.forEach(O,this),this.reset(!0)}function P(t){if(t){var e=t[u];if(e)return e.call(t);if("function"==typeof t.next)return t;if(!isNaN(t.length)){var r=-1,n=function e(){for(;++r<t.length;)if(i.call(t,r))return e.value=t[r],e.done=!1,e;return e.value=void 0,e.done=!0,e};return n.next=n}}return{next:A}}function A(){return{value:void 0,done:!0}}return y.prototype=v,a(E,"constructor",{value:v,configurable:!0}),a(v,"constructor",{value:y,configurable:!0}),y.displayName=l(v,p,"GeneratorFunction"),e.isGeneratorFunction=function(t){var e="function"==typeof t&&t.constructor;return!!e&&(e===y||"GeneratorFunction"===(e.displayName||e.name))},e.mark=function(t){return Object.setPrototypeOf?Object.setPrototypeOf(t,v):(t.__proto__=v,l(t,p,"GeneratorFunction")),t.prototype=Object.create(E),t},e.awrap=function(t){return{__await:t}},_(x.prototype),l(x.prototype,s,(function(){return this})),e.AsyncIterator=x,e.async=function(t,r,n,o,i){void 0===i&&(i=Promise);var a=new x(f(t,r,n,o),i);return e.isGeneratorFunction(r)?a:a.next().then((function(t){return t.done?t.value:a.next()}))},_(E),l(E,p,"Generator"),l(E,u,(function(){return this})),l(E,"toString",(function(){return"[object Generator]"})),e.keys=function(t){var e=Object(t),r=[];for(var n in e)r.push(n);return r.reverse(),function t(){for(;r.length;){var n=r.pop();if(n in e)return t.value=n,t.done=!1,t}return t.done=!0,t}},e.values=P,T.prototype={constructor:T,reset:function(t){if(this.prev=0,this.next=0,this.sent=this._sent=void 0,this.done=!1,this.delegate=null,this.method="next",this.arg=void 0,this.tryEntries.forEach(j),!t)for(var e in this)"t"===e.charAt(0)&&i.call(this,e)&&!isNaN(+e.slice(1))&&(this[e]=void 0)},stop:function(){this.done=!0;var t=this.tryEntries[0].completion;if("throw"===t.type)throw t.arg;return this.rval},dispatchException:function(t){if(this.done)throw t;var e=this;function r(r,n){return a.type="throw",a.arg=t,e.next=r,n&&(e.method="next",e.arg=void 0),!!n}for(var n=this.tryEntries.length-1;n>=0;--n){var o=this.tryEntries[n],a=o.completion;if("root"===o.tryLoc)return r("end");if(o.tryLoc<=this.prev){var c=i.call(o,"catchLoc"),u=i.call(o,"finallyLoc");if(c&&u){if(this.prev<o.catchLoc)return r(o.catchLoc,!0);if(this.prev<o.finallyLoc)return r(o.finallyLoc)}else if(c){if(this.prev<o.catchLoc)return r(o.catchLoc,!0)}else{if(!u)throw new Error("try statement without catch or finally");if(this.prev<o.finallyLoc)return r(o.finallyLoc)}}}},abrupt:function(t,e){for(var r=this.tryEntries.length-1;r>=0;--r){var n=this.tryEntries[r];if(n.tryLoc<=this.prev&&i.call(n,"finallyLoc")&&this.prev<n.finallyLoc){var o=n;break}}o&&("break"===t||"continue"===t)&&o.tryLoc<=e&&e<=o.finallyLoc&&(o=null);var a=o?o.completion:{};return a.type=t,a.arg=e,o?(this.method="next",this.next=o.finallyLoc,h):this.complete(a)},complete:function(t,e){if("throw"===t.type)throw t.arg;return"break"===t.type||"continue"===t.type?this.next=t.arg:"return"===t.type?(this.rval=this.arg=t.arg,this.method="return",this.next="end"):"normal"===t.type&&e&&(this.next=e),h},finish:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var r=this.tryEntries[e];if(r.finallyLoc===t)return this.complete(r.completion,r.afterLoc),j(r),h}},catch:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var r=this.tryEntries[e];if(r.tryLoc===t){var n=r.completion;if("throw"===n.type){var o=n.arg;j(r)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(t,e,r){return this.delegate={iterator:P(t),resultName:e,nextLoc:r},"next"===this.method&&(this.arg=void 0),h}},e}t.exports=o,t.exports.__esModule=!0,t.exports.default=t.exports},7501:t=>{function e(r){return t.exports=e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},t.exports.__esModule=!0,t.exports.default=t.exports,e(r)}t.exports=e,t.exports.__esModule=!0,t.exports.default=t.exports},824:(t,e,r)=>{var n=r(1337)();t.exports=n;try{regeneratorRuntime=n}catch(t){"object"==typeof globalThis?globalThis.regeneratorRuntime=n:Function("r","regeneratorRuntime = r")(n)}}},e={};function r(n){var o=e[n];if(void 0!==o)return o.exports;var i=e[n]={exports:{}};return t[n](i,i.exports,r),i.exports}r.n=t=>{var e=t&&t.__esModule?()=>t.default:()=>t;return r.d(e,{a:e}),e},r.d=(t,e)=>{for(var n in e)r.o(e,n)&&!r.o(t,n)&&Object.defineProperty(t,n,{enumerable:!0,get:e[n]})},r.o=(t,e)=>Object.prototype.hasOwnProperty.call(t,e),(()=>{"use strict";function t(t,e){(null==e||e>t.length)&&(e=t.length);for(var r=0,n=new Array(e);r<e;r++)n[r]=t[r];return n}function e(e){return function(e){if(Array.isArray(e))return t(e)}(e)||function(t){if("undefined"!=typeof Symbol&&null!=t[Symbol.iterator]||null!=t["@@iterator"])return Array.from(t)}(e)||function(e,r){if(e){if("string"==typeof e)return t(e,r);var n=Object.prototype.toString.call(e).slice(8,-1);return"Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n?Array.from(e):"Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?t(e,r):void 0}}(e)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function n(t,e,r,n,o,i,a){try{var c=t[i](a),u=c.value}catch(t){return void r(t)}c.done?e(u):Promise.resolve(u).then(n,o)}function o(t){return function(){var e=this,r=arguments;return new Promise((function(o,i){var a=t.apply(e,r);function c(t){n(a,o,i,c,u,"next",t)}function u(t){n(a,o,i,c,u,"throw",t)}c(void 0)}))}}function i(t){return i="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},i(t)}function a(t){var e=function(t,e){if("object"!==i(t)||null===t)return t;var r=t[Symbol.toPrimitive];if(void 0!==r){var n=r.call(t,e||"default");if("object"!==i(n))return n;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===e?String:Number)(t)}(t,"string");return"symbol"===i(e)?e:String(e)}function c(t,e){for(var r=0;r<e.length;r++){var n=e[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,a(n.key),n)}}function u(t){if(void 0===t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return t}function s(t,e){return s=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,e){return t.__proto__=e,t},s(t,e)}function p(t,e){if(e&&("object"===i(e)||"function"==typeof e))return e;if(void 0!==e)throw new TypeError("Derived constructors may only return object or undefined");return u(t)}function l(t){return l=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(t){return t.__proto__||Object.getPrototypeOf(t)},l(t)}function f(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],(function(){}))),!0}catch(t){return!1}}function d(t,e,r){return d=f()?Reflect.construct.bind():function(t,e,r){var n=[null];n.push.apply(n,e);var o=new(Function.bind.apply(t,n));return r&&s(o,r.prototype),o},d.apply(null,arguments)}function h(t){var e="function"==typeof Map?new Map:void 0;return h=function(t){if(null===t||(r=t,-1===Function.toString.call(r).indexOf("[native code]")))return t;var r;if("function"!=typeof t)throw new TypeError("Super expression must either be null or a function");if(void 0!==e){if(e.has(t))return e.get(t);e.set(t,n)}function n(){return d(t,arguments,l(this).constructor)}return n.prototype=Object.create(t.prototype,{constructor:{value:n,enumerable:!1,writable:!0,configurable:!0}}),s(n,t)},h(t)}var m=r(824),y=r.n(m);function v(){this.entries=[]}function b(t,e){w(t);var r=function(t,e){w(t),function(t){if(!Array.isArray(t))throw new TypeError(t+" is not an array.");if(0===t.length)return[];if(!t[0].hasOwnProperty("name"))throw new Error(t[0]+"does not contain name key.");if("string"!=typeof t[0].name)throw new TypeError("Invalid value type passed for name of option "+t[0].name+". Value should be string.")}(e);var r=[];return e.forEach((function(e){for(var n=0;n<t.options.length;n++)if(t.options[n].name.toLowerCase()===e.name.toLowerCase()){r[n]=e.value;break}})),r}(t,e);return function(t,e){w(t),function(t){if(Array.isArray(t)&&"object"==typeof t[0])throw new Error(t+"is not a valid array of options.")}(e);var r=t.variants.filter((function(t){return e.every((function(e,r){return t.options[r]===e}))}));return r[0]||null}(t,r)}function w(t){if("object"!=typeof t)throw new TypeError(t+" is not an object.");if(0===Object.keys(t).length&&t.constructor===Object)throw new Error(t+" is empty.")}v.prototype.add=function(t,e,r){this.entries.push({element:t,event:e,fn:r}),t.addEventListener(e,r)},v.prototype.removeAll=function(){this.entries=this.entries.filter((function(t){return t.element.removeEventListener(t.event,t.fn),!1}))};var g='[name="id"]',E='[name^="options"]',_='[name="quantity"]',x='[name^="properties"]';function S(t,e,r){this.element=t,this.product=function(t){if("object"!=typeof t)throw new TypeError(t+" is not an object.");if(void 0===t.variants[0].options)throw new TypeError("Product object is invalid. Make sure you use the product object that is output from {{ product | json }} or from the http://[your-product-url].js route");return t}(e),r=r||{},this._listeners=new v,this._listeners.add(this.element,"submit",this._onSubmit.bind(this,r)),this.optionInputs=this._initInputs(E,r.onOptionChange),this.quantityInputs=this._initInputs(_,r.onQuantityChange),this.propertyInputs=this._initInputs(x,r.onPropertyChange)}S.prototype.destroy=function(){this._listeners.removeAll()},S.prototype.options=function(){return t=this.optionInputs,e=function(t){return t.name=/(?:^(options\[))(.*?)(?:\])/.exec(t.name)[2],t},t.reduce((function(t,r){return(r.checked||"radio"!==r.type&&"checkbox"!==r.type)&&t.push(e({name:r.name,value:r.value})),t}),[]);var t,e},S.prototype.variant=function(){return b(this.product,this.options())},S.prototype.properties=function(){var t,e,r=(t=this.propertyInputs,e=function(t){return/(?:^(properties\[))(.*?)(?:\])/.exec(t)[2]},t.reduce((function(t,r){return(r.checked||"radio"!==r.type&&"checkbox"!==r.type)&&(t[e(r.name)]=r.value),t}),{}));return 0===Object.entries(r).length?null:r},S.prototype.quantity=function(){return this.quantityInputs[0]?Number.parseInt(this.quantityInputs[0].value,10):1},S.prototype._setIdInputValue=function(t){var e=this.element.querySelector(g);e||((e=document.createElement("input")).type="hidden",e.name="id",this.element.appendChild(e)),e.value=t.toString()},S.prototype._onSubmit=function(t,e){e.dataset=this._getProductFormEventData(),e.dataset.variant&&this._setIdInputValue(e.dataset.variant.id),t.onFormSubmit&&t.onFormSubmit(e)},S.prototype._onFormEvent=function(t){return void 0===t?Function.prototype:function(e){e.dataset=this._getProductFormEventData(),t(e)}.bind(this)},S.prototype._initInputs=function(t,e){return Array.prototype.slice.call(this.element.querySelectorAll(t)).map(function(t){return this._listeners.add(t,"change",this._onFormEvent(e)),t}.bind(this))},S.prototype._getProductFormEventData=function(){return{options:this.options(),variant:this.variant(),properties:this.properties(),quantity:this.quantity()}};function L(t,e){"string"==typeof t&&(t=t.replace(".",""));let r="";const n=/\{\{\s*(\w+)\s*\}\}/,o=e||"${{amount}}";function i(t,e=2,r=",",n="."){if(isNaN(t)||null==t)return 0;const o=(t=(t/100).toFixed(e)).split(".");return o[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g,`$1${r}`)+(o[1]?n+o[1]:"")}switch(o.match(n)[1]){case"amount":r=i(t,2);break;case"amount_no_decimals":r=i(t,0);break;case"amount_with_comma_separator":r=i(t,2,".",",");break;case"amount_no_decimals_with_comma_separator":r=i(t,0,".",",")}return o.replace(n,r)}var O=function(t,e){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},n=new CustomEvent(e,{detail:r});t.dispatchEvent(n)},j=function(){var t=o(y().mark((function t(e,r){var n,o;return y().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return e&&(e.description&&200!==e.status?window.toast.error({message:e.description,icon:!1}):r||window.dispatchEvent(new Event("dynamic-cart-open"))),O(window,"update-react",{}),O(window,"ajax-cart",{cartSections:e.sections}),t.next=5,fetch("/cart.js");case 5:return n=t.sent,t.next=8,n.json();case 8:o=t.sent,window.BOLD&&BOLD.common&&BOLD.common.cartDoctor&&"function"==typeof BOLD.common.cartDoctor.fix&&(o=BOLD.common.cartDoctor.fix(o)),window.BOLD&&BOLD.common&&BOLD.common.eventEmitter&&"function"==typeof BOLD.common.eventEmitter.emit&&BOLD.common.eventEmitter.emit("BOLD_COMMON_cart_loaded",o);case 11:case"end":return t.stop()}}),t)})));return function(e,r){return t.apply(this,arguments)}}(),T=function(){var t=o(y().mark((function t(e){var r,n;return y().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return window.dispatchEvent(new Event("dynamic-cart-loading")),t.next=3,fetch("/cart/add.js",{method:"POST",body:(o=e,Array.from(new FormData(o),(function(t){return t.map(encodeURIComponent).join("=")})).join("&")+"&sections[]=cart-main&sections[]=header"),headers:{"Content-Type":"application/x-www-form-urlencoded"}});case 3:return r=t.sent,t.next=6,r.json();case 6:n=t.sent,j(n);case 8:case"end":return t.stop()}var o}),t)})));return function(e){return t.apply(this,arguments)}}();function P(t){var e=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],(function(){}))),!0}catch(t){return!1}}();return function(){var r,n=l(t);if(e){var o=l(this).constructor;r=Reflect.construct(n,arguments,o)}else r=n.apply(this,arguments);return p(this,r)}}var A=function(t){!function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function");t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,writable:!0,configurable:!0}}),Object.defineProperty(t,"prototype",{writable:!1}),e&&s(t,e)}(f,t);var r,n,i,a,p,l=P(f);function f(){var t;return function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,f),(t=l.call(this)).productWrapper=t.closest("[data-product-wrapper]"),t.priceWrapperElement=t.closest("[data-product-wrapper]").querySelector(".price"),t.priceWrapperElement&&(t.priceElement=Array.from(t.priceWrapperElement.querySelectorAll("[data-price]")),t.comparePriceElement=Array.from(t.priceWrapperElement.querySelectorAll("[data-compare-at-price]"))),t.priceWrapperElementATC=document.querySelector(".submit-price"),t.priceWrapperElementATC&&(t.priceElementATC=Array.from(t.priceWrapperElementATC.querySelectorAll("[data-price]")),t.comparePriceElementATC=Array.from(t.priceWrapperElementATC.querySelectorAll("[data-compare-at-price]"))),t.imageSwiper=t.productWrapper.querySelector("[data-product-image-swiper]"),t.productHandle=t.getAttribute("product-handle"),t.productFormElement=t.querySelector("form"),t.submitButton=t.querySelector("[data-submit-product]"),t.submitButtonText=t.querySelectorAll("[data-submit-text]"),t.selectId=t.querySelector('[name="id"]'),t.allSwatches=Array.from(t.querySelectorAll("[data-option-position]")),t.initializeForm(),t.productFormElement.addEventListener("submit",t.submitProductForm.bind(u(t))),t}return r=f,n=[{key:"initializeForm",value:(p=o(y().mark((function t(){return y().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,this.getProductJson(this.productHandle);case 2:this.product=t.sent,this.productForm=new S(this.productFormElement,this.product,{onOptionChange:this.optionsChange.bind(this)});case 4:case"end":return t.stop()}}),t,this)}))),function(){return p.apply(this,arguments)})},{key:"getProductJson",value:function(t){return fetch("/products/".concat(t,".js")).then((function(t){return t.json()}))}},{key:"submitProductForm",value:(a=o(y().mark((function t(e){return y().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return e.preventDefault(),this.submitButton.classList.add("loading"),t.next=4,T(this.productFormElement);case 4:this.submitButton.classList.remove("loading");case 5:case"end":return t.stop()}}),t,this)}))),function(t){return a.apply(this,arguments)})},{key:"optionsChange",value:function(t){var e=t.dataset.variant;this.updateBrowserHistory(e),this.updateMainSelect(e),this.updateProductPrice(e),this.updateOutOfStockOptions(e),this.updateProductButton(e),this.updateSlideImages(e)}},{key:"updateBrowserHistory",value:function(t){if(t){var e=function(t,e){return/variant=/.test(t)?t.replace(/(variant=)[^&]+/,"$1"+e):/\?/.test(t)?t.concat("&variant=").concat(e):t.concat("?variant=").concat(e)}(window.location.href,t.id);window.history.replaceState({path:e},"",e)}}},{key:"updateMainSelect",value:function(t){t&&(this.selectId.value=t.id,this.selectId.dispatchEvent(new Event("change")))}},{key:"updateProductPrice",value:function(t){if(this.priceWrapperElement.classList.toggle("hide",!t),t){if(this.priceElement.forEach((function(e){return e.innerHTML=L(t.price,theme.moneyFormat)})),this.comparePriceElement.forEach((function(e){return e.innerHTML=L(t.compare_at_price,theme.moneyFormat)})),this.priceElementATC.forEach((function(e){return e.innerHTML=L(t.price,theme.moneyFormat)})),this.comparePriceElementATC.forEach((function(e){return e.innerHTML=L(t.compare_at_price,theme.moneyFormat)})),this.submitButton.classList.contains("bold_hidden")){var e=document.querySelector(".bold_clone .submit-price");if(e){var r=Array.from(e.querySelectorAll("[data-price]")),n=Array.from(e.querySelectorAll("[data-compare-at-price]"));r.forEach((function(e){return e.innerHTML=L(t.price,theme.moneyFormat)})),n.forEach((function(e){return e.innerHTML=L(t.compare_at_price,theme.moneyFormat)}))}}t.compare_at_price>t.price?this.priceWrapperElement.classList.add("price--on-sale"):this.priceWrapperElement.classList.remove("price--on-sale"),t.available?this.priceWrapperElement.classList.remove("price--sold-out"):this.priceWrapperElement.classList.add("price--sold-out")}}},{key:"updateProductButton",value:function(t){this.submitButtonText.forEach((function(t){return t.innerHTML=""})),t?t.available?(this.submitButton.disabled=!1,this.submitButtonText.forEach((function(t){return t.innerHTML=theme.strings.product.addToCart}))):(this.submitButton.disabled=!0,this.submitButtonText.forEach((function(t){return t.innerHTML=theme.strings.product.soldOut}))):(this.submitButton.disabled=!0,this.submitButtonText.forEach((function(t){return t.innerHTML=theme.strings.product.unavailable})))}},{key:"updateOutOfStockOptions",value:function(){var t=this,e=this.querySelector("input[id^=Option1]:checked"),r=this.querySelector("input[id^=Option2]:checked"),n=this.querySelector("input[id^=Option3]:checked"),o=e?e.value:null,i=r?r.value:null,a=n?n.value:null,c=e.closest(".product-form__option").querySelector("[data-selected-option]");if(c&&(c.innerHTML=o),r){var u=r.closest(".product-form__option").querySelector("[data-selected-option]");u&&(u.innerHTML=i)}if(n){var s=n.closest(".product-form__option").querySelector("[data-selected-option]");s&&(s.innerHTML=a)}this.allSwatches.forEach((function(e){if(1==e.dataset.optionPosition)var r=t.product.variants.find((function(t){return t.option1===e.value&&t.available}));else 2==e.dataset.optionPosition?r=t.product.variants.find((function(t){return t.option1===o&&t.option2===e.value&&t.available})):3==e.dataset.optionPosition&&(r=t.product.variants.find((function(t){return t.option1===o&&t.option2===i&&t.option3===e.value&&t.available})));r?e.classList.remove("swatches__disabled"):e.classList.add("swatches__disabled")}))}},{key:"updateSlideImages",value:function(t){if(t&&this.imageSwiper&&t.featured_media){var r=t.featured_media.id,n=this.imageSwiper.querySelector('[data-media-id="'.concat(r,'"]')),o=e(Array.from(this.imageSwiper.querySelectorAll(".swiper-slide"))).indexOf(n);-1===o&&(o=0),this.imageSwiper.swiper.slideTo(o,500)}}}],n&&c(r.prototype,n),i&&c(r,i),Object.defineProperty(r,"prototype",{writable:!1}),f}(h(HTMLElement));try{customElements.define("product-form",A)}catch(t){console.log("product-form already defined",t)}})()})();



(() => {
    var t = {
            1337: (t, e, r) => {
                var n = r(7501).default;

                function o() {
                    "use strict";
                    t.exports = o = function() {
                        return e
                    }, t.exports.__esModule = !0, t.exports.default = t.exports;
                    var e = {},
                        r = Object.prototype,
                        i = r.hasOwnProperty,
                        a = Object.defineProperty || function(t, e, r) {
                            t[e] = r.value
                        },
                        c = "function" == typeof Symbol ? Symbol : {},
                        u = c.iterator || "@@iterator",
                        s = c.asyncIterator || "@@asyncIterator",
                        p = c.toStringTag || "@@toStringTag";

                    function l(t, e, r) {
                        return Object.defineProperty(t, e, {
                            value: r,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }), t[e]
                    }
                    try {
                        l({}, "")
                    } catch (t) {
                        l = function(t, e, r) {
                            return t[e] = r
                        }
                    }

                    function f(t, e, r, n) {
                        var o = e && e.prototype instanceof m ? e : m,
                            i = Object.create(o.prototype),
                            c = new T(n || []);
                        return a(i, "_invoke", {
                            value: S(t, r, c)
                        }), i
                    }

                    function d(t, e, r) {
                        try {
                            return {
                                type: "normal",
                                arg: t.call(e, r)
                            }
                        } catch (t) {
                            return {
                                type: "throw",
                                arg: t
                            }
                        }
                    }
                    e.wrap = f;
                    var h = {};

                    function m() {}

                    function y() {}

                    function v() {}
                    var b = {};
                    l(b, u, (function() {
                        return this
                    }));
                    var w = Object.getPrototypeOf,
                        g = w && w(w(P([])));
                    g && g !== r && i.call(g, u) && (b = g);
                    var E = v.prototype = m.prototype = Object.create(b);

                    function _(t) {
                        ["next", "throw", "return"].forEach((function(e) {
                            l(t, e, (function(t) {
                                return this._invoke(e, t)
                            }))
                        }))
                    }

                    function x(t, e) {
                        function r(o, a, c, u) {
                            var s = d(t[o], t, a);
                            if ("throw" !== s.type) {
                                var p = s.arg,
                                    l = p.value;
                                return l && "object" == n(l) && i.call(l, "__await") ? e.resolve(l.__await).then((function(t) {
                                    r("next", t, c, u)
                                }), (function(t) {
                                    r("throw", t, c, u)
                                })) : e.resolve(l).then((function(t) {
                                    p.value = t, c(p)
                                }), (function(t) {
                                    return r("throw", t, c, u)
                                }))
                            }
                            u(s.arg)
                        }
                        var o;
                        a(this, "_invoke", {
                            value: function(t, n) {
                                function i() {
                                    return new e((function(e, o) {
                                        r(t, n, e, o)
                                    }))
                                }
                                return o = o ? o.then(i, i) : i()
                            }
                        })
                    }

                    function S(t, e, r) {
                        var n = "suspendedStart";
                        return function(o, i) {
                            if ("executing" === n) throw new Error("Generator is already running");
                            if ("completed" === n) {
                                if ("throw" === o) throw i;
                                return A()
                            }
                            for (r.method = o, r.arg = i;;) {
                                var a = r.delegate;
                                if (a) {
                                    var c = L(a, r);
                                    if (c) {
                                        if (c === h) continue;
                                        return c
                                    }
                                }
                                if ("next" === r.method) r.sent = r._sent = r.arg;
                                else if ("throw" === r.method) {
                                    if ("suspendedStart" === n) throw n = "completed", r.arg;
                                    r.dispatchException(r.arg)
                                } else "return" === r.method && r.abrupt("return", r.arg);
                                n = "executing";
                                var u = d(t, e, r);
                                if ("normal" === u.type) {
                                    if (n = r.done ? "completed" : "suspendedYield", u.arg === h) continue;
                                    return {
                                        value: u.arg,
                                        done: r.done
                                    }
                                }
                                "throw" === u.type && (n = "completed", r.method = "throw", r.arg = u.arg)
                            }
                        }
                    }

                    function L(t, e) {
                        var r = e.method,
                            n = t.iterator[r];
                        if (void 0 === n) return e.delegate = null, "throw" === r && t.iterator.return && (e.method = "return", e.arg = void 0, L(t, e), "throw" === e.method) || "return" !== r && (e.method = "throw", e.arg = new TypeError("The iterator does not provide a '" + r + "' method")), h;
                        var o = d(n, t.iterator, e.arg);
                        if ("throw" === o.type) return e.method = "throw", e.arg = o.arg, e.delegate = null, h;
                        var i = o.arg;
                        return i ? i.done ? (e[t.resultName] = i.value, e.next = t.nextLoc, "return" !== e.method && (e.method = "next", e.arg = void 0), e.delegate = null, h) : i : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, h)
                    }

                    function O(t) {
                        var e = {
                            tryLoc: t[0]
                        };
                        1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
                    }

                    function j(t) {
                        var e = t.completion || {};
                        e.type = "normal", delete e.arg, t.completion = e
                    }

                    function T(t) {
                        this.tryEntries = [{
                            tryLoc: "root"
                        }], t.forEach(O, this), this.reset(!0)
                    }

                    function P(t) {
                        if (t) {
                            var e = t[u];
                            if (e) return e.call(t);
                            if ("function" == typeof t.next) return t;
                            if (!isNaN(t.length)) {
                                var r = -1,
                                    n = function e() {
                                        for (; ++r < t.length;)
                                            if (i.call(t, r)) return e.value = t[r], e.done = !1, e;
                                        return e.value = void 0, e.done = !0, e
                                    };
                                return n.next = n
                            }
                        }
                        return {
                            next: A
                        }
                    }

                    function A() {
                        return {
                            value: void 0,
                            done: !0
                        }
                    }
                    return y.prototype = v, a(E, "constructor", {
                        value: v,
                        configurable: !0
                    }), a(v, "constructor", {
                        value: y,
                        configurable: !0
                    }), y.displayName = l(v, p, "GeneratorFunction"), e.isGeneratorFunction = function(t) {
                        var e = "function" == typeof t && t.constructor;
                        return !!e && (e === y || "GeneratorFunction" === (e.displayName || e.name))
                    }, e.mark = function(t) {
                        return Object.setPrototypeOf ? Object.setPrototypeOf(t, v) : (t.__proto__ = v, l(t, p, "GeneratorFunction")), t.prototype = Object.create(E), t
                    }, e.awrap = function(t) {
                        return {
                            __await: t
                        }
                    }, _(x.prototype), l(x.prototype, s, (function() {
                        return this
                    })), e.AsyncIterator = x, e.async = function(t, r, n, o, i) {
                        void 0 === i && (i = Promise);
                        var a = new x(f(t, r, n, o), i);
                        return e.isGeneratorFunction(r) ? a : a.next().then((function(t) {
                            return t.done ? t.value : a.next()
                        }))
                    }, _(E), l(E, p, "Generator"), l(E, u, (function() {
                        return this
                    })), l(E, "toString", (function() {
                        return "[object Generator]"
                    })), e.keys = function(t) {
                        var e = Object(t),
                            r = [];
                        for (var n in e) r.push(n);
                        return r.reverse(),
                            function t() {
                                for (; r.length;) {
                                    var n = r.pop();
                                    if (n in e) return t.value = n, t.done = !1, t
                                }
                                return t.done = !0, t
                            }
                    }, e.values = P, T.prototype = {
                        constructor: T,
                        reset: function(t) {
                            if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(j), !t)
                                for (var e in this) "t" === e.charAt(0) && i.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0)
                        },
                        stop: function() {
                            this.done = !0;
                            var t = this.tryEntries[0].completion;
                            if ("throw" === t.type) throw t.arg;
                            return this.rval
                        },
                        dispatchException: function(t) {
                            if (this.done) throw t;
                            var e = this;

                            function r(r, n) {
                                return a.type = "throw", a.arg = t, e.next = r, n && (e.method = "next", e.arg = void 0), !!n
                            }
                            for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                                var o = this.tryEntries[n],
                                    a = o.completion;
                                if ("root" === o.tryLoc) return r("end");
                                if (o.tryLoc <= this.prev) {
                                    var c = i.call(o, "catchLoc"),
                                        u = i.call(o, "finallyLoc");
                                    if (c && u) {
                                        if (this.prev < o.catchLoc) return r(o.catchLoc, !0);
                                        if (this.prev < o.finallyLoc) return r(o.finallyLoc)
                                    } else if (c) {
                                        if (this.prev < o.catchLoc) return r(o.catchLoc, !0)
                                    } else {
                                        if (!u) throw new Error("try statement without catch or finally");
                                        if (this.prev < o.finallyLoc) return r(o.finallyLoc)
                                    }
                                }
                            }
                        },
                        abrupt: function(t, e) {
                            for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                                var n = this.tryEntries[r];
                                if (n.tryLoc <= this.prev && i.call(n, "finallyLoc") && this.prev < n.finallyLoc) {
                                    var o = n;
                                    break
                                }
                            }
                            o && ("break" === t || "continue" === t) && o.tryLoc <= e && e <= o.finallyLoc && (o = null);
                            var a = o ? o.completion : {};
                            return a.type = t, a.arg = e, o ? (this.method = "next", this.next = o.finallyLoc, h) : this.complete(a)
                        },
                        complete: function(t, e) {
                            if ("throw" === t.type) throw t.arg;
                            return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), h
                        },
                        finish: function(t) {
                            for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                var r = this.tryEntries[e];
                                if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), j(r), h
                            }
                        },
                        catch: function(t) {
                            for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                var r = this.tryEntries[e];
                                if (r.tryLoc === t) {
                                    var n = r.completion;
                                    if ("throw" === n.type) {
                                        var o = n.arg;
                                        j(r)
                                    }
                                    return o
                                }
                            }
                            throw new Error("illegal catch attempt")
                        },
                        delegateYield: function(t, e, r) {
                            return this.delegate = {
                                iterator: P(t),
                                resultName: e,
                                nextLoc: r
                            }, "next" === this.method && (this.arg = void 0), h
                        }
                    }, e
                }
                t.exports = o, t.exports.__esModule = !0, t.exports.default = t.exports
            },
            7501: t => {
                function e(r) {
                    return t.exports = e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    }, t.exports.__esModule = !0, t.exports.default = t.exports, e(r)
                }
                t.exports = e, t.exports.__esModule = !0, t.exports.default = t.exports
            },
            824: (t, e, r) => {
                var n = r(1337)();
                t.exports = n;
                try {
                    regeneratorRuntime = n
                } catch (t) {
                    "object" == typeof globalThis ? globalThis.regeneratorRuntime = n : Function("r", "regeneratorRuntime = r")(n)
                }
            }
        },
        e = {};

    function r(n) {
        var o = e[n];
        if (void 0 !== o) return o.exports;
        var i = e[n] = {
            exports: {}
        };
        return t[n](i, i.exports, r), i.exports
    }
    r.n = t => {
        var e = t && t.__esModule ? () => t.default : () => t;
        return r.d(e, {
            a: e
        }), e
    }, r.d = (t, e) => {
        for (var n in e) r.o(e, n) && !r.o(t, n) && Object.defineProperty(t, n, {
            enumerable: !0,
            get: e[n]
        })
    }, r.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e), (() => {
        "use strict";

        function t(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
            return n
        }

        function e(e) {
            return function(e) {
                if (Array.isArray(e)) return t(e)
            }(e) || function(t) {
                if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
            }(e) || function(e, r) {
                if (e) {
                    if ("string" == typeof e) return t(e, r);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? t(e, r) : void 0
                }
            }(e) || function() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }()
        }

        function n(t, e, r, n, o, i, a) {
            try {
                var c = t[i](a),
                    u = c.value
            } catch (t) {
                return void r(t)
            }
            c.done ? e(u) : Promise.resolve(u).then(n, o)
        }

        function o(t) {
            return function() {
                var e = this,
                    r = arguments;
                return new Promise((function(o, i) {
                    var a = t.apply(e, r);

                    function c(t) {
                        n(a, o, i, c, u, "next", t)
                    }

                    function u(t) {
                        n(a, o, i, c, u, "throw", t)
                    }
                    c(void 0)
                }))
            }
        }

        function i(t) {
            return i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            }, i(t)
        }

        function a(t) {
            var e = function(t, e) {
                if ("object" !== i(t) || null === t) return t;
                var r = t[Symbol.toPrimitive];
                if (void 0 !== r) {
                    var n = r.call(t, e || "default");
                    if ("object" !== i(n)) return n;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === e ? String : Number)(t)
            }(t, "string");
            return "symbol" === i(e) ? e : String(e)
        }

        function c(t, e) {
            for (var r = 0; r < e.length; r++) {
                var n = e[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, a(n.key), n)
            }
        }

        function u(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }

        function s(t, e) {
            return s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
                return t.__proto__ = e, t
            }, s(t, e)
        }

        function p(t, e) {
            if (e && ("object" === i(e) || "function" == typeof e)) return e;
            if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
            return u(t)
        }

        function l(t) {
            return l = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t)
            }, l(t)
        }

        function f() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
            } catch (t) {
                return !1
            }
        }

        function d(t, e, r) {
            return d = f() ? Reflect.construct.bind() : function(t, e, r) {
                var n = [null];
                n.push.apply(n, e);
                var o = new(Function.bind.apply(t, n));
                return r && s(o, r.prototype), o
            }, d.apply(null, arguments)
        }

        function h(t) {
            var e = "function" == typeof Map ? new Map : void 0;
            return h = function(t) {
                if (null === t || (r = t, -1 === Function.toString.call(r).indexOf("[native code]"))) return t;
                var r;
                if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function");
                if (void 0 !== e) {
                    if (e.has(t)) return e.get(t);
                    e.set(t, n)
                }

                function n() {
                    return d(t, arguments, l(this).constructor)
                }
                return n.prototype = Object.create(t.prototype, {
                    constructor: {
                        value: n,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }
                }), s(n, t)
            }, h(t)
        }
        var m = r(824),
            y = r.n(m);

        function v() {
            this.entries = []
        }

        function b(t, e) {
            w(t);
            var r = function(t, e) {
                w(t),
                    function(t) {
                        if (!Array.isArray(t)) throw new TypeError(t + " is not an array.");
                        if (0 === t.length) return [];
                        if (!t[0].hasOwnProperty("name")) throw new Error(t[0] + "does not contain name key.");
                        if ("string" != typeof t[0].name) throw new TypeError("Invalid value type passed for name of option " + t[0].name + ". Value should be string.")
                    }(e);
                var r = [];
                return e.forEach((function(e) {
                    for (var n = 0; n < t.options.length; n++)
                        if (t.options[n].name.toLowerCase() === e.name.toLowerCase()) {
                            r[n] = e.value;
                            break
                        }
                })), r
            }(t, e);
            return function(t, e) {
                w(t),
                    function(t) {
                        if (Array.isArray(t) && "object" == typeof t[0]) throw new Error(t + "is not a valid array of options.")
                    }(e);
                var r = t.variants.filter((function(t) {
                    return e.every((function(e, r) {
                        return t.options[r] === e
                    }))
                }));
                return r[0] || null
            }(t, r)
        }

        function w(t) {
            if ("object" != typeof t) throw new TypeError(t + " is not an object.");
            if (0 === Object.keys(t).length && t.constructor === Object) throw new Error(t + " is empty.")
        }
        v.prototype.add = function(t, e, r) {
            this.entries.push({
                element: t,
                event: e,
                fn: r
            }), t.addEventListener(e, r)
        }, v.prototype.removeAll = function() {
            this.entries = this.entries.filter((function(t) {
                return t.element.removeEventListener(t.event, t.fn), !1
            }))
        };
        var g = '[name="id"]',
            E = '[name^="options"]',
            _ = '[name="quantity"]',
            x = '[name^="properties"]';

        function S(t, e, r) {
            this.element = t, this.product = function(t) {
                if ("object" != typeof t) throw new TypeError(t + " is not an object.");
                if (void 0 === t.variants[0].options) throw new TypeError("Product object is invalid. Make sure you use the product object that is output from {{ product | json }} or from the http://[your-product-url].js route");
                return t
            }(e), r = r || {}, this._listeners = new v, this._listeners.add(this.element, "submit", this._onSubmit.bind(this, r)), this.optionInputs = this._initInputs(E, r.onOptionChange), this.quantityInputs = this._initInputs(_, r.onQuantityChange), this.propertyInputs = this._initInputs(x, r.onPropertyChange)
        }
        S.prototype.destroy = function() {
            this._listeners.removeAll()
        }, S.prototype.options = function() {
            return t = this.optionInputs, e = function(t) {
                return t.name = /(?:^(options\[))(.*?)(?:\])/.exec(t.name)[2], t
            }, t.reduce((function(t, r) {
                return (r.checked || "radio" !== r.type && "checkbox" !== r.type) && t.push(e({
                    name: r.name,
                    value: r.value
                })), t
            }), []);
            var t, e
        }, S.prototype.variant = function() {
            return b(this.product, this.options())
        }, S.prototype.properties = function() {
            var t, e, r = (t = this.propertyInputs, e = function(t) {
                return /(?:^(properties\[))(.*?)(?:\])/.exec(t)[2]
            }, t.reduce((function(t, r) {
                return (r.checked || "radio" !== r.type && "checkbox" !== r.type) && (t[e(r.name)] = r.value), t
            }), {}));
            return 0 === Object.entries(r).length ? null : r
        }, S.prototype.quantity = function() {
            return this.quantityInputs[0] ? Number.parseInt(this.quantityInputs[0].value, 10) : 1
        }, S.prototype._setIdInputValue = function(t) {
            var e = this.element.querySelector(g);
            e || ((e = document.createElement("input")).type = "hidden", e.name = "id", this.element.appendChild(e)), e.value = t.toString()
        }, S.prototype._onSubmit = function(t, e) {
            e.dataset = this._getProductFormEventData(), e.dataset.variant && this._setIdInputValue(e.dataset.variant.id), t.onFormSubmit && t.onFormSubmit(e)
        }, S.prototype._onFormEvent = function(t) {
            return void 0 === t ? Function.prototype : function(e) {
                e.dataset = this._getProductFormEventData(), t(e)
            }.bind(this)
        }, S.prototype._initInputs = function(t, e) {
            return Array.prototype.slice.call(this.element.querySelectorAll(t)).map(function(t) {
                return this._listeners.add(t, "change", this._onFormEvent(e)), t
            }.bind(this))
        }, S.prototype._getProductFormEventData = function() {
            return {
                options: this.options(),
                variant: this.variant(),
                properties: this.properties(),
                quantity: this.quantity()
            }
        };

        function L(t, e) {
            "string" == typeof t && (t = t.replace(".", ""));
            let r = "";
            const n = /\{\{\s*(\w+)\s*\}\}/,
                o = e || "${{amount}}";

            function i(t, e = 2, r = ",", n = ".") {
                if (isNaN(t) || null == t) return 0;
                const o = (t = (t / 100).toFixed(e)).split(".");
                return o[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, `$1${r}`) + (o[1] ? n + o[1] : "")
            }
            switch (o.match(n)[1]) {
                case "amount":
                    r = i(t, 2);
                    break;
                case "amount_no_decimals":
                    r = i(t, 0);
                    break;
                case "amount_with_comma_separator":
                    r = i(t, 2, ".", ",");
                    break;
                case "amount_no_decimals_with_comma_separator":
                    r = i(t, 0, ".", ",")
            }
            return o.replace(n, r)
        }
        var O = function(t, e) {
                var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                    n = new CustomEvent(e, {
                        detail: r
                    });
                t.dispatchEvent(n)
            },
            j = function() {
                var t = o(y().mark((function t(e, r) {
                    var n, o;
                    return y().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e && (e.description && 200 !== e.status ? window.toast.error({
                                    message: e.description,
                                    icon: !1
                                }) : r || window.dispatchEvent(new Event("dynamic-cart-open"))), O(window, "update-react", {}), O(window, "ajax-cart", {
                                    cartSections: e.sections
                                }), t.next = 5, fetch("/cart.js");
                            case 5:
                                return n = t.sent, t.next = 8, n.json();
                            case 8:
                                o = t.sent, window.BOLD && BOLD.common && BOLD.common.cartDoctor && "function" == typeof BOLD.common.cartDoctor.fix && (o = BOLD.common.cartDoctor.fix(o)), window.BOLD && BOLD.common && BOLD.common.eventEmitter && "function" == typeof BOLD.common.eventEmitter.emit && BOLD.common.eventEmitter.emit("BOLD_COMMON_cart_loaded", o);
                            case 11:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                })));
                return function(e, r) {
                    return t.apply(this, arguments)
                }
            }(),
            T = function() {
                var t = o(y().mark((function t(e) {
                    var r, n;
                    return y().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return window.dispatchEvent(new Event("dynamic-cart-loading")), t.next = 3, fetch("/cart/add.js", {
                                    method: "POST",
                                    body: (o = e, Array.from(new FormData(o), (function(t) {
                                        return t.map(encodeURIComponent).join("=")
                                    })).join("&") + "&sections[]=cart-main&sections[]=header"),
                                    headers: {
                                        "Content-Type": "application/x-www-form-urlencoded"
                                    }
                                });
                            case 3:
                                return r = t.sent, t.next = 6, r.json();
                            case 6:
                                n = t.sent, j(n);
                            case 8:
                            case "end":
                                return t.stop()
                        }
                        var o
                    }), t)
                })));
                return function(e) {
                    return t.apply(this, arguments)
                }
            }();

        function P(t) {
            var e = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (t) {
                    return !1
                }
            }();
            return function() {
                var r, n = l(t);
                if (e) {
                    var o = l(this).constructor;
                    r = Reflect.construct(n, arguments, o)
                } else r = n.apply(this, arguments);
                return p(this, r)
            }
        }
        var A = function(t) {
            ! function(t, e) {
                if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(t, "prototype", {
                    writable: !1
                }), e && s(t, e)
            }(f, t);
            var r, n, i, a, p, l = P(f);

            function f() {
                var t;
                return function(t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }(this, f), (t = l.call(this)).productWrapper = t.closest("[data-product-wrapper]"), t.priceWrapperElement = t.closest("[data-product-wrapper]").querySelector(".price"), t.priceWrapperElement && (t.priceElement = Array.from(t.priceWrapperElement.querySelectorAll("[data-price]")), t.comparePriceElement = Array.from(t.priceWrapperElement.querySelectorAll("[data-compare-at-price]"))), t.priceWrapperElementATC = document.querySelector(".submit-price"), t.priceWrapperElementATC && (t.priceElementATC = Array.from(t.priceWrapperElementATC.querySelectorAll("[data-price]")), t.comparePriceElementATC = Array.from(t.priceWrapperElementATC.querySelectorAll("[data-compare-at-price]"))), t.imageSwiper = t.productWrapper.querySelector("[data-product-image-swiper]"), t.productHandle = t.getAttribute("product-handle"), t.productFormElement = t.querySelector("form"), t.submitButton = t.querySelector("[data-submit-product]"), t.submitButtonText = t.querySelectorAll("[data-submit-text]"), t.selectId = t.querySelector('[name="id"]'), t.allSwatches = Array.from(t.querySelectorAll("[data-option-position]")), t.initializeForm(), t.productFormElement.addEventListener("submit", t.submitProductForm.bind(u(t))), t
            }
            return r = f, n = [{
                key: "initializeForm",
                value: (p = o(y().mark((function t() {
                    return y().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.getProductJson(this.productHandle);
                            case 2:
                                this.product = t.sent, this.productForm = new S(this.productFormElement, this.product, {
                                    onOptionChange: this.optionsChange.bind(this)
                                });
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return p.apply(this, arguments)
                })
            }, {
                key: "getProductJson",
                value: function(t) {
                    return fetch("/products/".concat(t, ".js")).then((function(t) {
                        return t.json()
                    }))
                }
            }, {
                key: "submitProductForm",
                value: (a = o(y().mark((function t(e) {
                    return y().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e.preventDefault(), this.submitButton.classList.add("loading"), t.next = 4, T(this.productFormElement);
                            case 4:
                                this.submitButton.classList.remove("loading");

                                  var saddle_selected = $('.get__saddle_add_on input[type="radio"]:checked').attr('data-value');
                                      var saddle__text = $('.get__saddle_add_on .engraved_text .required').val();
                                      console.log(saddle__text);
                                    if(saddle_selected == 'Yes'){
                                    jQuery.post('/cart/add.js', {
                                            quantity: 1,
                                            id: 1104663657,
                                            properties: {
                                              'ENGRAVED TEXT: FINAL SALE ': saddle__text
                                            }
                                            });
                                    }

                             /*---------Add Free Plate on Halter----------*/
                                var is_Add_free_plate = $('.product-main__product-form .product-form').attr('data-halter');
                                if(is_Add_free_plate == 'Add_free_plate'){
                                var get_saddle_product = $(".halter__name_plate_selectbox option:selected").attr('data-id');
                                console.log(get_saddle_product);
                                  jQuery.post('/cart/add.js', {
                                            quantity: 1,
                                            id: get_saddle_product
                                            });
                                }
                                /*-------Add Round Tag product on Dog Collar--------*/        
                               var is_add_round_tag = $('.product-main__product-form .product-form').attr('data-roundtag');
                                if(is_add_round_tag == 'Add_Round_tag'){
                                var get_roundtag_product = $(".pet_belt_engraving .dog_coller_add_round_tag input:checked").attr('data-id');
                                  // console.log(get_roundtag_product);
                                
                                  jQuery.post('/cart/add.js', {
                                            quantity: 1,
                                            id: get_roundtag_product
                                            });
                                }
                             /*-------Add 2 free mask when you purchase 1 mask--------*/        
                            var is_apply_free_mask = $('.product-main__product-form .product-form').attr('data-freemask');
                            console.log(is_apply_free_mask);
                            if(is_apply_free_mask == 'enable_2_free_mask'){
                                  jQuery.post('/cart/add.js', {
                                            quantity: 2,
                                            id: 42745584222385
                                            });
                                }
                            case 5:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t) {
                    return a.apply(this, arguments)
                })
            }, {
                key: "optionsChange",
                value: function(t) {
                    var e = t.dataset.variant;
                    this.updateBrowserHistory(e), this.updateMainSelect(e), this.updateProductPrice(e), this.updateOutOfStockOptions(e), this.updateProductButton(e), this.updateSlideImages(e);
                  // console.log("e----",e.option3);
                  var twoline_engr = e.option3;
                  if(twoline_engr == 'Two lines of Engraving'){
                    $('.engraved__txt_second_line').show();
                    console.log("hello");
                  }
                  else{
                    $('.engraved__txt_second_line').hide();
                  }
                }
            }, {
                key: "updateBrowserHistory",
                value: function(t) {
                    if (t) {
                        var e = function(t, e) {
                            return /variant=/.test(t) ? t.replace(/(variant=)[^&]+/, "$1" + e) : /\?/.test(t) ? t.concat("&variant=").concat(e) : t.concat("?variant=").concat(e)
                        }(window.location.href, t.id);
                        window.history.replaceState({
                            path: e
                        }, "", e)
                    }
                }
            }, {
                key: "updateMainSelect",
                value: function(t) {
                    t && (this.selectId.value = t.id, this.selectId.dispatchEvent(new Event("change")))
                }
            }, {
                key: "updateProductPrice",
                value: function(t) {
                    if (this.priceWrapperElement.classList.toggle("hide", !t), t) {
                        if (this.priceElement.forEach((function(e) {
                                return e.innerHTML = L(t.price, theme.moneyFormat)
                            })), this.comparePriceElement.forEach((function(e) {
                                return e.innerHTML = L(t.compare_at_price, theme.moneyFormat)
                            })), this.priceElementATC.forEach((function(e) {
                                return e.innerHTML = L(t.price, theme.moneyFormat)
                            })), this.comparePriceElementATC.forEach((function(e) {
                                return e.innerHTML = L(t.compare_at_price, theme.moneyFormat)
                            })), this.submitButton.classList.contains("bold_hidden")) {
                            var e = document.querySelector(".bold_clone .submit-price");
                            if (e) {
                                var r = Array.from(e.querySelectorAll("[data-price]")),
                                    n = Array.from(e.querySelectorAll("[data-compare-at-price]"));
                                r.forEach((function(e) {
                                    return e.innerHTML = L(t.price, theme.moneyFormat)
                                })), n.forEach((function(e) {
                                    return e.innerHTML = L(t.compare_at_price, theme.moneyFormat)
                                }))
                            }
                        }
                        t.compare_at_price > t.price ? this.priceWrapperElement.classList.add("price--on-sale") : this.priceWrapperElement.classList.remove("price--on-sale"), t.available ? this.priceWrapperElement.classList.remove("price--sold-out") : this.priceWrapperElement.classList.add("price--sold-out")
                    }
                }
            }, {
                key: "updateProductButton",
                value: function(t) {
                    this.submitButtonText.forEach((function(t) {
                        return t.innerHTML = ""
                    })), t ? t.available ? (this.submitButton.disabled = !1, this.submitButtonText.forEach((function(t) {
                        return t.innerHTML = theme.strings.product.addToCart
                    }))) : (this.submitButton.disabled = !0, this.submitButtonText.forEach((function(t) {
                        return t.innerHTML = theme.strings.product.soldOut
                    }))) : (this.submitButton.disabled = !0, this.submitButtonText.forEach((function(t) {
                        return t.innerHTML = theme.strings.product.unavailable
                    })))
                }
            }, {
                key: "updateOutOfStockOptions",
                value: function() {
                    var t = this,
                        e = this.querySelector("input[id^=Option1]:checked"),
                        r = this.querySelector("input[id^=Option2]:checked"),
                        n = this.querySelector("input[id^=Option3]:checked"),
                        o = e ? e.value : null,
                        i = r ? r.value : null,
                        a = n ? n.value : null,
                        c = e.closest(".product-form__option").querySelector("[data-selected-option]");
                    if (c && (c.innerHTML = o), r) {
                        var u = r.closest(".product-form__option").querySelector("[data-selected-option]");
                        u && (u.innerHTML = i)
                    }
                    if (n) {
                        var s = n.closest(".product-form__option").querySelector("[data-selected-option]");
                        s && (s.innerHTML = a)
                    }
                    this.allSwatches.forEach((function(e) {
                        if (1 == e.dataset.optionPosition) var r = t.product.variants.find((function(t) {
                            return t.option1 === e.value && t.available
                        }));
                        else 2 == e.dataset.optionPosition ? r = t.product.variants.find((function(t) {
                            return t.option1 === o && t.option2 === e.value && t.available
                        })) : 3 == e.dataset.optionPosition && (r = t.product.variants.find((function(t) {
                            return t.option1 === o && t.option2 === i && t.option3 === e.value && t.available
                        })));
                        r ? e.classList.remove("swatches__disabled") : e.classList.add("swatches__disabled")
                    }))
                }
            }, {
                key: "updateSlideImages",
                value: function(t) {
                    if (t && this.imageSwiper && t.featured_media) {
                        var r = t.featured_media.id,
                            n = this.imageSwiper.querySelector('[data-media-id="'.concat(r, '"]')),
                            o = e(Array.from(this.imageSwiper.querySelectorAll(".swiper-slide"))).indexOf(n); - 1 === o && (o = 0), this.imageSwiper.swiper.slideTo(o, 500)
                    }
                }
            }], n && c(r.prototype, n), i && c(r, i), Object.defineProperty(r, "prototype", {
                writable: !1
            }), f
        }(h(HTMLElement));
        try {
            customElements.define("product-form", A)
        } catch (t) {
            console.log("product-form already defined", t)
        }
    })()
})();