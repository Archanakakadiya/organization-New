
  $(document).ready(function() {

    
$('.engraved__txt_second_line, .dog_coller_add_round_tag__outer').hide();
    /*-----------add Saddle product with another products-----Start-----*/
    $('.get__saddle_add_on input[type="radio"]').click(function() {
      // console.log(this);
       if($(this).attr('id') == 'yes_saddle') {
         var get_engr_txt_html = $(".engr__line").html();
         console.log(get_engr_txt_html);
         $('.get__saddle_add_on').append(get_engr_txt_html);
         $(".get__saddle_add_on .engraved_text").addClass("show").removeClass("hide");  
       }
       else {
         $('.get__saddle_add_on .engraved_text').remove();
            $(".get__saddle_add_on .engraved_text").addClass("hide").removeClass("show");           
       }
   });

    
    // $(document).on("click",".product-form__submit",function() {
    //   setTimeout(function() {
    // // var saddle_selected = $('.get__saddle_add_on input[type="radio"]:checked').attr('data-value');
    // //     var saddle__text = $('.get__saddle_add_on .engraved_text .required').val();
    // //     console.log(saddle__text);
    // //   if(saddle_selected == 'Yes'){
    // //   jQuery.post('/cart/add.js', {
    // //           quantity: 1,
    // //           id: 1104663657,
    // //           properties: {
    // //             'ENGRAVED TEXT: FINAL SALE ': saddle__text
    // //           }
    // //           });
    // //   }
    //   }, 200);
    // });
/*-----------add Saddle product with another products-----End-----*/
/*----------change selectbox value and add free varaint as per selectbox value-----------------Start-------------*/
    
    $('.halter__name_plate_selectbox').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
      var twoword = "two";
      if(valueSelected.indexOf(twoword) != -1){
         $('.halter__name_plate_outer_div .engraved__txt_second_line').show();
      }
      else{
        $('.halter__name_plate_outer_div .engraved__txt_second_line').hide();
      }
});
    /*----------change selectbox value and add free varaint as per selectbox value-----------------End-------------*/

/*Padded Dog Collar add engraving and add ROUND TAG --------Start-----*/
$('.pet_belt_engraving input[type="radio"]').click(function() {
      
      if($(this).attr('id') == 'Yes_Round_tag'){
         var get_round_tag_txt_html = $(".dog_coller_add_round_tag__outer").html();
         // console.log(get_engr_txt_html);
         $('.pet_belt_engraving').append(get_round_tag_txt_html);
         $('.pet_belt_engraving .dog_coller_add_round_tag__outer').show();
       }
       else {
          // $('.pet_belt_engraving .dog_coller_add_round_tag').hide();
             $('.pet_belt_engraving .dog_coller_add_round_tag').remove();         
       }
   });

    /*Padded Dog Collar add engraving and add ROUND TAG --------End-----*/

var if_price_attr = $('.Static_price_is_avail').attr('data-price');

  
    if (typeof if_price_attr !== typeof undefined && if_price_attr !== false) {
  var get_static_price = $('.Static_price_is_avail').data('price');
  $('.product-form__submit .price').text("$"+get_static_price);
}
/*-------------------------This code is for Jog Harness-----------------------------------*/
if ($('body').hasClass('template_7490936930481')) {

   $('.tcustomizer-field-305302 .tcustomizer__dropdown option, .tcustomizer-field-203971 .tcustomizer__dropdown option').each(function() {
    var optionText = $(this).text();
    var trimmedText = optionText.split('+')[0].trim();
    $(this).text(trimmedText);
  });
 $('.tcustomizer-field-305302 .tcustomizer__dropdown').change(function() {
   
    var selectedOption_305302 = $(this).find(':selected').text();
    if(selectedOption_305302 == 'Combination Work Bridle'){
      $('.tcustomizer-field-671676 .tcustomizer__dropdown').change(function() {
        var selectedOption_671676 = $(this).find(':selected').text();
         var selectedOption_671676_trimmedText = selectedOption_671676.split('$')[1].trim();

var default_price_ = $('.Static_price_is_avail').data('price');
        // var default_price_ = "1500";
        var sum_with_selected_val = parseFloat(default_price_) + parseFloat(selectedOption_671676_trimmedText);
        $('.template_7490936930481 .product-main__price .price-item , .template_7490936930481 .submit-price .price').text("$"+sum_with_selected_val+".00");
      });
    }
   else{
     var get_static_price = $('.Static_price_is_avail').data('price');
   $('.template_7490936930481 .product-main__price .price-item , .template_7490936930481 .submit-price .price').text("$"+ get_static_price);  
   }
  });

}

if ($('body').hasClass('template_7492446355633')) {
  $('.tcustomizer-field-396510 input[type="radio"]').change(function () {
    var value__396510 = $('.tcustomizer-field-396510 input[type="radio"]:checked').siblings().text();

    if (value__396510.indexOf('Yes') != -1) {
      var selectedOption_396510_trimmedText = value__396510.split('$')[1].trim();
      var default_price_ = $('.Static_price_is_avail').data('price');
      var sum_with_selected_val = parseFloat(default_price_) + parseFloat(selectedOption_396510_trimmedText);
          $('.template_7492446355633 .product-main__price .price-item , .template_7492446355633 .submit-price .price').text("$"+sum_with_selected_val+".00");
    }
    else{
      var get_static_price = $('.Static_price_is_avail').data('price');
      $('.template_7492446355633 .product-main__price .price-item , .template_7492446355633 .submit-price .price').text("$"+ get_static_price);  
    }
  });
}
  
  });


















// Browband javascript for images -----------

$(window).on('load', function() {
  // $('.product-form__submit.tcustomizer-overlap-button').prop("disabled", true);
  var whole_browband_text = "";

  
  var selected_trap = "style_wide";
  var selected_inside_color = "inside_color_Black";
  var selected_edge_color = "edge_none";
  var selected_pipe_color = "pipe_color_black";
  var dots_option = "";
  var currant_val_pipe = "";
  function add_to_cart_condition(){
    
  }
function load_images(){
  $('.broband_varaint_img .browband___pro_image').each(function(){
  var get_the_alt = $(this).data('alt');
    var alt_compare = $('.product_custom_option_').text();
    if (get_the_alt == alt_compare) {
      $(this).show();
    }
    else{
      $(this).hide();
    }
  });
}
function load_options_of_dots_pipe(wide_straight_trim){
  
      if(wide_straight_trim == 'Small Dots' || wide_straight_trim == 'Large Dots'){
  
             $('.tcustomizer-field.tcustomizer-field-906788 , .tcustomizer-field.tcustomizer-field-353149, .tcustomizer-field.tcustomizer-field-820952, .tcustomizer-field.tcustomizer-field-719003').hide();
          
                var selected_val_698948 = $('.tcustomizer-field-698948 input[type="radio"]:checked').val()
                if(selected_val_698948 == 'Horseshoe'){
                  $('.tcustomizer-field.tcustomizer-field-353149').show();
                }
           else{
                      $('.tcustomizer-field.tcustomizer-field-353149').hide();
                }
              $('.tcustomizer-field-698948 input[type="radio"]').click(function() {
                  var selected_val_698948 = $('.tcustomizer-field-698948 input[type="radio"]:checked').val()
                 if(selected_val_698948 == 'Horseshoe'){
                      $('.tcustomizer-field.tcustomizer-field-353149').show();
                    }
                else{
                      $('.tcustomizer-field.tcustomizer-field-353149').hide();
                }
                });
      }
      else{
         $('.tcustomizer-field.tcustomizer-field-906788 , .tcustomizer-field.tcustomizer-field-353149, .tcustomizer-field.tcustomizer-field-820952, .tcustomizer-field.tcustomizer-field-719003').show();
      }
  }
function trim_options_setup(wide_straight_trim){
    function pipe_color_option(active_val_155326, active_val_316961){
      console.log("active_val_316961-",active_val_316961)
                if(active_val_155326 == "Burgundy" || active_val_316961 == "Burgundy"){
                  trim_pipe_color = ",pipe_color_burgundy";
                }
                else if(active_val_155326 == "Candy Apple Dark Red" || active_val_316961 == "Candy Apple Dark Red"){
                  trim_pipe_color = ",pipe_color_red";
                }
                else if(active_val_155326 == "Black" || active_val_316961 == "Black"){
                  trim_pipe_color = ",pipe_color_black";
                }
                else{
                  trim_pipe_color = ",pipe_color_burgundy";
                }
               $('.product_custom_option_').append(trim_pipe_color);
    }
    function dots_color_option(active_val_948344){
        
                  if(active_val_948344 == "Burgundy"){
                    trim_dots_color = ",dots_color_burgundy";
                  }
                  else if(active_val_948344 == "Candy Apple Dark Red"){
                    trim_dots_color = ",dots_color_red";
                  }
                    else if(active_val_948344 == "Black"){
                    trim_dots_color = ",dots_color_black";
                  }
                  else if(active_val_948344 == "White"){
                    trim_dots_color = ",dots_color_white";
                  }
                  else{
                    trim_dots_color = ",dots_color_burgundy";
                  }
                 $('.product_custom_option_').append(trim_dots_color);
      }

              // var remove_value_155326 = $('.product_custom_option_').text();
              // var commaIndex = remove_value_155326.indexOf(',');
              // var active_val_155326 = "";
              // remove_value_155326 =  remove_value_155326.substring(0, commaIndex).replace(/\b,trim_\w*,?/g, '')+ remove_value_155326.substring(commaIndex);;
              // $('.product_custom_option_').text(remove_value_155326);


                  var remove_value_58699 = $('.product_custom_option_').text();
                  var words_remove_value_58699 = remove_value_58699.split(',');
                  var filtered_value_58699 = words_remove_value_58699.filter(function(words_remove_value_58699) {
                    return !words_remove_value_58699.startsWith("trim_") && !words_remove_value_58699.startsWith("pipe_color_") && !words_remove_value_58699.startsWith("dots_color_");
                  });
                  var new_val_custom_option = filtered_value_58699.join(',');
                  $('.product_custom_option_').text(new_val_custom_option);

  

                  //  var remove_value_58699 = $('.product_custom_option_').text();
                  // var words_remove_value_58699 = remove_value_58699.split(',');
                  // var filtered_value_58699 = words_remove_value_58699.filter(function(words_remove_value_58699) {
                  //   // return !words_remove_value_58699.startsWith("trim_");
                  //   return !words_remove_value_58699.startsWith(",trim_") && !words_remove_value_58699.startsWith(",pipe_color_") && !words_remove_value_58699.startsWith(",dots_color_");
                  // });
                  // var new_val_custom_option = filtered_value_58699.join(',');
                  // $('.product_custom_option_').text(new_val_custom_option);


                var selected_type = $('.tcustomizer-field-843781').find('.tcustomizer__image--active').data("title");
                if(selected_type == 'Narrow Tapered'){
                  var wide_straight_trim = $('.tcustomizer-field-343886').find('.tcustomizer__image--active').data("title");
                  }
                else{
                  var wide_straight_trim = $('.tcustomizer-field-58699').find('.tcustomizer__image--active').data("title");
                }
  var trim_pipe_color = "";
  var trim_dots_color = "";
    if(wide_straight_trim == 'Piping'){
      
       wide_straight_trim_text = ",trim_pipe";
       $('.product_custom_option_').append(wide_straight_trim_text);

            if ($('.tcustomizer-field-155326 .tcustomizer__image').hasClass('tcustomizer__image--active')) {
              var active_val_155326 = $('.tcustomizer-field-155326').find('.tcustomizer__image--active').data("title");
              pipe_color_option(active_val_155326);
            }
             $('.tcustomizer-field-155326 input[type="radio"]').click(function() {
               var active_val_155326 = $('.tcustomizer-field-155326').find('.tcustomizer__image--active').data("title");
               var remove_value_155326 = $('.product_custom_option_').text();
                remove_value_155326 =  remove_value_155326.replace(/\b,pipe_color_\w*,?/g, '');
                $('.product_custom_option_').text(remove_value_155326);
                 pipe_color_option(active_val_155326);
                load_images();
             });

              if ($('.tcustomizer-field-316961 .tcustomizer__image').hasClass('tcustomizer__image--active')) {
                var active_val_316961 = $('.tcustomizer-field-316961').find('.tcustomizer__image--active').data("title");
                pipe_color_option(active_val_316961);
              }
               $('.tcustomizer-field-316961 input[type="radio"]').click(function() {
                 var active_val_316961 = $('.tcustomizer-field-316961').find('.tcustomizer__image--active').data("title");
                 var remove_value_316961 = $('.product_custom_option_').text();
                  remove_value_316961 =  remove_value_316961.replace(/\b,pipe_color_\w*,?/g, '');
                  $('.product_custom_option_').text(remove_value_316961);
                   pipe_color_option(active_val_316961);
                  load_images();
               });
     $('.tcustomizer-field.tcustomizer-field-906788 , .tcustomizer-field.tcustomizer-field-353149, .tcustomizer-field.tcustomizer-field-820952, .tcustomizer-field.tcustomizer-field-719003').show();
    }
    if(wide_straight_trim == 'Small Dots'){
     wide_straight_trim_text = ",trim_small_dots";
       $('.product_custom_option_').append(wide_straight_trim_text);
    
    }
    if(wide_straight_trim == 'Large Dots'){
     wide_straight_trim_text = ",trim_large_dots";
       $('.product_custom_option_').append(wide_straight_trim_text);
    }
   if(wide_straight_trim != 'Piping'){

        if ($('.tcustomizer-field-948344 .tcustomizer__image').hasClass('tcustomizer__image--active')) {
                var active_val_948344 = $('.tcustomizer-field-948344').find('.tcustomizer__image--active').data("title");
                dots_color_option(active_val_948344);
              }
        $('.tcustomizer-field-948344 input[type="radio"]').click(function() {
                 var active_val_948344 = $('.tcustomizer-field-948344').find('.tcustomizer__image--active').data("title");
                 var remove_value_948344 = $('.product_custom_option_').text();
                  remove_value_948344 =  remove_value_948344.replace(/\b,dots_color_\w*,?/g, '');
                  $('.product_custom_option_').text(remove_value_948344);
                   dots_color_option(active_val_948344);
                  load_images();
               });

     $('.tcustomizer-field.tcustomizer-field-906788 , .tcustomizer-field.tcustomizer-field-353149, .tcustomizer-field.tcustomizer-field-820952, .tcustomizer-field.tcustomizer-field-719003').hide();
   }
  load_options_of_dots_pipe(wide_straight_trim);
}
function value_of_843781(selected_trap){



                   var get_custom_option = $('.product_custom_option_').text();
                  var get_843781 = get_custom_option.replace(/\bstyle_\w*,?/g, selected_trap+",");
                  $('.product_custom_option_').text(get_843781);


  
  
  // var remove_value_843781 = $('.product_custom_option_').text();
  //     remove_value_843781 =  remove_value_843781.replace(/\bstyle_\w*,?/g, selected_trap);
  //     $('.product_custom_option_').text(remove_value_843781);
  // load_images();
}
  function value_of_77443(selected_inside_color){
     var remove_value_77443 = $('.product_custom_option_').text();
      remove_value_77443 =  remove_value_77443.replace(/\binside_color_\w*,?/g, selected_inside_color+",");
      $('.product_custom_option_').text(remove_value_77443);
      load_images();
  }
  function value_of_236396(selected_edge_color){

      // var active_val_948344 = $('.tcustomizer-field-948344').find('.tcustomizer__image--active').data("title");
       var remove_value_236396 = $('.product_custom_option_').text();
        remove_value_236396 =  remove_value_236396.replace(/\bedge_\w*,?/g, selected_edge_color);
        $('.product_custom_option_').text(remove_value_236396);
   
        load_images();




    
      // var remove_value_236396 = $('.product_custom_option_').text();
      // remove_value_236396 =  remove_value_236396.replace(/\bedge_\w*,?/g, selected_edge_color);
      // $('.product_custom_option_').text(remove_value_236396);
      // load_images();
  
  }
  
  $('.tcustomizer-customization-form input[type="radio"]').click(function() {
    var currant_val = $(this).val();

    $('.browband_featured_image').hide();
    

    
    /*---------------------------- This is for style-----------------------------*/
    if($(this).parents('.tcustomizer-field').hasClass("tcustomizer-field-843781")){
                  
                  var remove_value_155326 = $('.product_custom_option_').text();
                  var words_remove_value_155326 = remove_value_155326.split(',');
                  var filtered_value_155326 = words_remove_value_155326.filter(function(words_remove_value_155326) {
                    return !words_remove_value_155326.startsWith("trim_") && !words_remove_value_155326.startsWith("pipe_color_");
                  });
                  var new_val_custom_option = filtered_value_155326.join(',');
                  $('.product_custom_option_').text(new_val_custom_option);
      
      if(currant_val == 'Narrow Tapered'){
        selected_trap = "style_narrow";
    
        
        if ($('.tcustomizer-field-343886 .tcustomizer__image').hasClass('tcustomizer__image--active')) {
          var wide_straight_trim = $('.tcustomizer-field-343886').find('.tcustomizer__image--active').data("title");
            if(wide_straight_trim == undefined){
                  var remove_value_155326 = $('.product_custom_option_').text();
                  var words_remove_value_155326 = remove_value_155326.split(',');
                  var filtered_value_155326 = words_remove_value_155326.filter(function(words_remove_value_155326) {
                    return !words_remove_value_155326.startsWith("trim_") && !words_remove_value_155326.startsWith("pipe_color_");
                  });
                  var new_val_custom_option = filtered_value_155326.join(',');
                  $('.product_custom_option_').text(new_val_custom_option);
                }
                else{
                  trim_options_setup(wide_straight_trim);
                }
        }
        $('.tcustomizer-field-343886 input[type="radio"]').click(function() {
          var wide_straight_trim = $('.tcustomizer-field-343886').find('.tcustomizer__image--active').data("title");
          
               if(wide_straight_trim == undefined){
                  var remove_value_155326 = $('.product_custom_option_').text();
                  var words_remove_value_155326 = remove_value_155326.split(',');
                  var filtered_value_155326 = words_remove_value_155326.filter(function(words_remove_value_155326) {
                    return !words_remove_value_155326.startsWith("trim_") && !words_remove_value_155326.startsWith("pipe_color_");
                  });
                  var new_val_custom_option = filtered_value_155326.join(',');
                  $('.product_custom_option_').text(new_val_custom_option);
                      $('.tcustomizer-field.tcustomizer-field-906788 , .tcustomizer-field.tcustomizer-field-353149, .tcustomizer-field.tcustomizer-field-820952, .tcustomizer-field.tcustomizer-field-719003').show();

                }
                else{
                  trim_options_setup(wide_straight_trim);
                }
        });
        $('.tcustomizer-field.tcustomizer-field-906788').show();

      }
      else if(currant_val == 'Wide Tapered'){
        selected_trap = "style_wide";
      }
      else if(currant_val == 'Straight'){
        selected_trap = "style_straight";
      }
      else{
        selected_trap = "style_wide";
      }

if(currant_val != 'Narrow Tapered'){


if ($('.tcustomizer-field-58699 .tcustomizer__image').hasClass('tcustomizer__image--active')) {
          var wide_straight_trim = $('.tcustomizer-field-58699').find('.tcustomizer__image--active').data("title");
            if(wide_straight_trim == undefined){
                  var remove_value_58699 = $('.product_custom_option_').text();
                  var words_remove_value_58699 = remove_value_58699.split(',');
                  var filtered_value_58699 = words_remove_value_58699.filter(function(words_remove_value_58699) {
                    return !words_remove_value_58699.startsWith("trim_") && !words_remove_value_58699.startsWith("pipe_color_");
                  });
                  var new_val_custom_option = filtered_value_58699.join(',');
                  $('.product_custom_option_').text(new_val_custom_option);
                   $('.tcustomizer-field.tcustomizer-field-906788 , .tcustomizer-field.tcustomizer-field-353149, .tcustomizer-field.tcustomizer-field-820952, .tcustomizer-field.tcustomizer-field-719003').show();
                }
                else{
                  trim_options_setup(wide_straight_trim);
                }
        }
  
  
  
$('.tcustomizer-field-58699 input[type="radio"]').click(function() {
          var wide_straight_trim = $('.tcustomizer-field-58699').find('.tcustomizer__image--active').data("title");
          
               if(wide_straight_trim == undefined){
                  var remove_value_58699 = $('.product_custom_option_').text();
                  var words_remove_value_58699 = remove_value_58699.split(',');
                  var filtered_value_58699 = words_remove_value_58699.filter(function(words_remove_value_58699) {
                    return !words_remove_value_58699.startsWith("trim_") && !words_remove_value_58699.startsWith("pipe_color_") && !words_remove_value_58699.startsWith("dots_color_");
                  });
                  var new_val_custom_option = filtered_value_58699.join(',');
                  $('.product_custom_option_').text(new_val_custom_option);
                      $('.tcustomizer-field.tcustomizer-field-906788 , .tcustomizer-field.tcustomizer-field-353149, .tcustomizer-field.tcustomizer-field-820952, .tcustomizer-field.tcustomizer-field-719003').show();

                }
                else{
                  trim_options_setup(wide_straight_trim);
                }
        });
}
      value_of_843781(selected_trap);
    }

/*---------------------------- This is for Center Color-----------------------------*/
if($(this).parents('.tcustomizer-field').hasClass("tcustomizer-field-77443")){
      if(currant_val == 'Burgundy'){
        selected_inside_color = "inside_color_burgundy";
      }
      else if(currant_val == 'Candy Apple Dark Red'){
        selected_inside_color = "inside_color_red";
      }
      else if(currant_val == 'Black'){
        selected_inside_color = "inside_color_black";
      }
      else{
        selected_inside_color = "inside_color_black";
      }
  value_of_77443(selected_inside_color);
    }

/*---------------------------- This is for Turned Edge color-----------------------------*/
if($(this).parents('.tcustomizer-field').hasClass("tcustomizer-field-236396")){
    if ($('.tcustomizer-field-236396 .tcustomizer__image').hasClass('tcustomizer__image--active')) {
           if(currant_val == 'Candy Apple Dark Red'){
            selected_edge_color = "edge_red";
          }
          else if(currant_val == 'Navy Blue'){
            selected_edge_color = "edge_navy";
          }
          else if(currant_val == 'White'){
            selected_edge_color = "edge_white";
          }
            else if(currant_val == 'Black'){
            selected_edge_color = "edge_black";
          }
       else{
            selected_edge_color = "edge_none,";
            }
      }
      else{
        selected_edge_color = "edge_none";
      }
     value_of_236396(selected_edge_color);
}

    
});
});