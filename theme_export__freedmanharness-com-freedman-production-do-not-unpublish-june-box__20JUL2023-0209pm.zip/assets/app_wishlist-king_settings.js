export default {
  "moveToCart": false,
  "loginRequired": false,
  "sharedWishlistPageHandle": "shared-wishlist",
  "wishlistPageHandle": "wishlist",
  "appmateAnalytics": true,
  "klaviyo": false,
  "facebookPixel": false,
  "googleAnalytics": false
}
