const _utils=function(){var t={getCart:function(){return $.getJSON("/cart.js")},getProductJSON:function(t){return $.getJSON(`/products/${t}.js`)},checkVariantInCart:function(n){return new Promise(function(e,r){t.getCart().then(function(t){var r=t.items.find(function(t){return t.variant_id==n});e(void 0!==r)})})},refreshCart:function(){setTimeout(function(){window.location.reload()},1e3)},addItemsToCart:function(n){return new Promise(function(e,r){async.eachSeries(n,function(n,e){t.addItemToCart(n).then(function(){e()})},function(t){t&&console.error(t),e()})})},addItemToCart:function(t){var n={quantity:t.quantity,id:t.variant_id};return void 0!==t.properties&&(n.properties=t.properties),console.log(n),new Promise(function(t,e){$.ajax({type:"POST",url:"/cart/add.js",data:n,dataType:"json",success:function(n){t(n)},error:function(t){e(t)}})})},removeItemsFromCart:function(t){if(0!=t.length){var n={};return t.forEach(function(t){n[t.key]=0}),new Promise(function(t,e){$.post("/cart/update.js",{updates:n,success:function(){t()}})})}},updateCart:function(t){if(t)return new Promise(function(n,e){$.ajax({type:"POST",url:"/cart/update.js",async:!0,data:{updates:t},dataType:"json",success:function(t){console.log(t),n(t)},error:function(t){console.error(t),e(t)}})})},updateCartAttribute:function(t){var n={attributes:{}};return n.attributes=t.attributes,new Promise(function(t,e){$.ajax("/cart/update.js",{type:"POST",data:n,success:function(){t()}})})},observeMutations:function(t,n){if(0!=document.querySelectorAll(t).length){var e=new MutationObserver(n);return e.observe(document.querySelector(t),{attributes:!0,childList:!0,characterData:!0}),e}},debounce:function(t,n,e){var r;return function(){var o=this,a=arguments,u=e&&!r;clearTimeout(r),r=setTimeout(function(){r=null,e||t.apply(o,a)},n),u&&t.apply(o,a)}},onElementLoad:function(t,n){var e=!1,r=setInterval(function(){document.querySelectorAll(t).length&&(console.log(t+" loaded!"),e=!0),e&&(clearInterval(r),n())},100)}};return t}();

function initApp() {
  Vue.use(Vuex);
  
  // Filters
  Vue.filter('resize_image', function(src, size) {
    var resized = src || '';
    resized = resized.replace('.png', `_${size}.png`);
    resized = resized.replace('.jpg', `_${size}.jpg`);
    
    return resized;
  });
  
  Vue.filter('handle', function(value) {
    return value.replace('-', ' ');    
  });
  
  Vue.filter('unhandle', function(value) {
    return value.replace('-', ' ');
  });  
  
  Vue.filter('format_money', function(value) {
    return Shopify.formatMoney(value, theme.moneyFormat);
  });
  
  if (document.querySelectorAll('#product-form--bridle-set').length) {
    var app = new Vue({
      el: '#product-form--bridle-set',

      data: {
        size: 'Horse',
        placeholder_product: placeholder_product,
        linked_products: products,
        options: options,
        discount: 0,
        app_url: "https://freedmans-harness.herokuapp.com"
        //app_url: 'https://9a98f639571d.ngrok.io'
      },

      computed: {},

      mounted: function() {
        var _this = this;
        
        // set discount from initial price difference
        _this.$set(_this, 'discount', _this.getTotalPrice() - _this.placeholder_product.price);
        _this.updatePrice();
      },
      
      updated: function () {
        this.$nextTick(function () {
          var _this = this;
        });
      },      

      methods: {
        getVariantsToAdd: function() {
          var _this = this;
          var variantsToAdd = [];
          console.log(_this.options)
          _this.options.included.products.forEach(function(product) {
            var includedVariant = product.variants.find(function(v) { return v.title.indexOf(_this.size) !== -1 });
            // check title if variant null
            if (!includedVariant) {
              includedVariant = product.variants.find(function(v) { return product.title.indexOf(_this.size) !== -1 });
            }
            
            // only include variant if not null or undefined
            if (includedVariant) {
              variantsToAdd = variantsToAdd.concat(includedVariant);
            }
          });
          
          for(var key in _this.options) {
            if (!_this.options[key].skipVariant) {
              var selected_option = _this.options[key].options.find(function(o) {
                return o.selected;
              });

              //console.log(selected_option);
              if (selected_option) {
                variantsToAdd = variantsToAdd.concat(
                  selected_option.change_by_size ? selected_option.product.variants.find(function(v) { return v.title.indexOf(_this.size) !== -1 }) : selected_option.variant_to_add
                );
              }
            }
          }
          
          _this.options.nameplate.variants_to_add.filter(function(variant) {
            return variant.hasOwnProperty('properties');
          }).forEach(function(variant) {
            variantsToAdd = variantsToAdd.concat(variant);
          });
          
          variantsToAdd.forEach(function(v) {
            var variant_qty = 1;

            var isAdvantageBridle = ['advantage-comfort-weymouth-double-bridle-2', 'advantage-padded-bridle'].indexOf(_this.placeholder_product.handle) !== -1;
            var isBridleCheek = v.name.indexOf('Bridle Cheeks') !== -1;

            if (isAdvantageBridle && isBridleCheek) {
              variant_qty = 2;
            }          
            v.quantity = variant_qty;
          });
          
          console.log(JSON.parse(JSON.stringify(variantsToAdd)));          
          
          return variantsToAdd;
        },
        
        getTotalWeight: function() {
          var _this = this;
          var qty = $('input[name="quantity"]').val();
          
          var variantsToAdd = _this.variantsToAdd;
          
          var total_weight = _this.getVariantsToAdd().reduce(function(weight, variant) {
            var variant_wt = variant.weight || 0;
            return weight += variant_wt * qty * variant.quantity;
          }, 0);
          
          return total_weight;          
        },
        
        getTotalPrice: function() {          
          var _this = this;
          var variantsToAdd = _this.getVariantsToAdd();
          
          var total_price = variantsToAdd.reduce(function(total, variant) {
            return total += variant.price * variant.quantity;
          }, 0);
          //console.log(total_price);
          
          return total_price;          
        },
        
        getFinalPrice: function() {
          var min = this.placeholder_product.price;
          var total = this.getTotalPrice() - this.discount;
          
          //return (total > min) ? total : min;
          return total;
        },
        
        updatePrice: function() {
          $('.current_price').text(Shopify.formatMoney(this.getFinalPrice(), theme.moneyFormat));
        },
        
        selectOption: function(e, option) {
          var _this = this;
          var $select = $(e.currentTarget);
          var optionIndex = $select.val();
          
          option.options.forEach(function(option) {
            option.selected = false;
          });
          option.options[optionIndex].selected = true;
          
          _this.updatePrice();
        },
        
        updateNamePlate: function(e) {
          var _this = this;
          
          var variants_to_add = [];
          //var variant = _this.options.nameplate.variant;

          // add selected nameplate variant
          var nameplate_variant = _this.options.nameplate_sku.options[0].variant_to_add;
          var selectedPlateSku = _this.options.nameplate_sku.options.find(function(o) {
            return o.selected;
          });
          if (selectedPlateSku) {
            nameplate_variant = selectedPlateSku.variant_to_add;
          }
          var variant = nameplate_variant;
          
          $('.nameplate').each(function(index, input) {
            var properties = {};
            var propValue = $(input).val();
            var propName = $(input).data('name');
            
            if (propValue !== '') {
              properties[propName] = propValue;
              variant.properties = properties;
              variants_to_add.push(variant);
            }
          });
          
          _this.options.nameplate.variants_to_add = variants_to_add;
          
          _this.updatePrice();
        },
        
        newBundleId: function() {
          return '_' + Math.random().toString(36).substr(2, 9);
        },
        
        addToCart: function(e) {
          var _this = this;
          var bundleGroup = _this.newBundleId();
          
          var variant_id = _this.placeholder_product.variants[0].id;
          var variant = _this.placeholder_product.variants.find(function(variant) {
            return variant.title == _this.size;
          });
          if (variant) {
            variant_id = variant.id;
          }
          
          
          var qty = $('input[name="quantity"]').val();
          var variants_size = _this.getVariantsToAdd().length
          var variants_to_add = _this.getVariantsToAdd().map(function(v) {
            var percent_discount = _this.discount / _this.getTotalPrice();
            var eachDiscount = Math.ceil(v.price * percent_discount);
            eachDiscount = Math.round((eachDiscount + Number.EPSILON)) / 100;

            var properties = v.properties;
            if(!properties) {
              properties = {};
            }

            properties['_bundle_name'] = bundleName;
            properties['_bundle_group'] = bundleGroup;
            
            return {
              id: v.id, 
              quantity: v.quantity,
              properties: properties
            }
          });
          
          var addItem = {
            variant_id: variant_id,
            quantity: qty,
            properties: {
              '__customProduct': "true",
              '__tailset': "true",
              '__total_weight': _this.getTotalWeight(),
              '__totalPrice': _this.getFinalPrice() + _this.discount,
              '__totalDiscount': _this.discount,
              '__discount_title': 'SET',
              '__variants': JSON.stringify(variants_to_add)
            }
          };

          console.log("variants", variants_to_add)
          
          
        }        
      }
    });
  }
}


$(document).ready(function() {
  initApp();
});

document.addEventListener('shopify:section:load', function (event) {
  initApp();
});
